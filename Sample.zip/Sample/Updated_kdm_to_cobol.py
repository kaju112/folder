#!/usr/bin/env python3
"""Regenerate the available COBOL source lines from a KDM/Neo4j CSV or XLSX export.

The reconstruction follows the rules in KDM_To_COBOL.docx. It is intentionally
loss-aware: the KDM table mainly covers executable statements, so source lines
that are not represented in the export remain blank unless paragraph recovery
can place a paragraph name there.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import pandas as pd


COLUMN_ALIASES = {
    "type": ["Type", "type", "node.type"],
    "name": ["Name", "name", "node.name"],
    "kind": ["Kind", "kind", "node.kind"],
    "seq_no": ["seqNo", "SeqNo", "seq_no", "sequence"],
    "start_pos": ["StartPos", "Start Pos", "startPos", "sPos", "start_pos"],
    "end_pos": ["EndPos", "End Pos", "endPos", "ePos", "end_pos"],
    "start_line": ["StartLine", "Start Line", "Start line", "startLine", "start_line"],
    "end_line": ["EndLine", "End Line", "End line", "endLine", "end_line"],
    "node_path": ["nodePath", "node.nodePath", "NodePath", "node_path"],
    "stmt_text": ["StmtText", "Stmnt Text", "Statement Text", "stmtText", "stmt_text"],
    "file_name": ["filename", "fileName", "FileName", "file_name"],
    "operating_mode": ["operatingmode", "operatingMode", "OperatingMode", "operating_mode"],
    "node_id": ["id", "node.id", "NodeId", "node_id"],
}


def _clean_header(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).strip().lower())


def _is_missing(value: Any) -> bool:
    if value is None or pd.isna(value):
        return True
    return str(value).strip().lower() in {"", "null", "none", "nan", "<na>"}


def _text(value: Any) -> str:
    return "" if _is_missing(value) else str(value).strip()


def _integer(value: Any, default: int | None = None) -> int | None:
    if _is_missing(value):
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, dtype=object, keep_default_na=True)
    if suffix in {".xlsx", ".xlsm"}:
        return pd.read_excel(path, sheet_name=sheet, dtype=object, engine="openpyxl")
    if suffix == ".xls":
        return pd.read_excel(path, sheet_name=sheet, dtype=object, engine="xlrd")
    raise ValueError(f"Unsupported input type: {suffix}. Use CSV, XLSX, XLSM, or XLS.")


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    normalized_lookup = {_clean_header(col): col for col in df.columns}
    rename_map: dict[str, str] = {}
    missing_required: list[str] = []

    for canonical, aliases in COLUMN_ALIASES.items():
        source = next((normalized_lookup[_clean_header(a)] for a in aliases
                       if _clean_header(a) in normalized_lookup), None)
        if source is not None:
            rename_map[source] = canonical
        elif canonical in {"start_line", "end_line", "kind", "stmt_text"}:
            missing_required.append(canonical)

    if missing_required:
        raise ValueError(
            "Missing required columns: " + ", ".join(missing_required) +
            ". Available columns: " + ", ".join(map(str, df.columns))
        )

    result = df.rename(columns=rename_map).copy()
    for optional in COLUMN_ALIASES:
        if optional not in result.columns:
            result[optional] = pd.NA

    for col in ["start_line", "end_line", "start_pos", "end_pos", "seq_no"]:
        result[col] = pd.to_numeric(result[col], errors="coerce").astype("Int64")

    result["kind"] = result["kind"].map(_text).str.upper()
    result["type"] = result["type"].map(_text)
    result["name"] = result["name"].map(_text)
    result["node_path"] = result["node_path"].map(_text)
    result["stmt_text"] = result["stmt_text"].map(_text)
    result["file_name"] = result["file_name"].map(_text)
    result["operating_mode"] = result["operating_mode"].map(_text).str.upper()

    # Preserve original XLSX/CSV line numbers for diagnostics.
    result["original_start_line"] = result["start_line"]
    result["original_end_line"] = result["end_line"]

    # Document rule: decrement every StartLine and EndLine by one.
    # Example: source line 112 becomes reconstructed COBOL line 111.post-decrement value
    result["start_line"] = result["start_line"] - 1
    result["end_line"] = result["end_line"] - 1

    # Convert decremented physical COBOL line numbers to zero-based list indexes.
    # Example: reconstructed COBOL line 111 is stored at lines[110].Python 0-based list position physical line 111, you must write to lines[110], because lines[0] is line 1, lines[1] is line 2
    result["start_idx"] = result["start_line"] - 1
    result["end_idx"] = result["end_line"] - 1

    # Validate both transformations, while accepting missing line values.
    start_line_ok = (result["start_line"] == result["original_start_line"] - 1).fillna(True)
    end_line_ok = (result["end_line"] == result["original_end_line"] - 1).fillna(True)
    start_idx_ok = (result["start_idx"] == result["start_line"] - 1).fillna(True)
    end_idx_ok = (result["end_idx"] == result["end_line"] - 1).fillna(True)

    if not bool(start_line_ok.all()):
        raise ValueError("StartLine decrement validation failed.")
    if not bool(end_line_ok.all()):
        raise ValueError("EndLine decrement validation failed.")
    if not bool(start_idx_ok.all()):
        raise ValueError("StartLine-to-list-index conversion failed.")
    if not bool(end_idx_ok.all()):
        raise ValueError("EndLine-to-list-index conversion failed.")

    # Stable ordering prevents duplicate-line rows from being rearranged unexpectedly.
    return result.sort_values(
        ["start_line", "node_path", "seq_no"],
        kind="stable",
        na_position="last",
    ).reset_index(drop=True)


def indent(start_pos: Any) -> str:
    # The pseudocode says StartPos - 1 spaces. Missing positions safely become zero.
    return " " * max((_integer(start_pos, 1) or 1) - 1, 0)


def put_line(lines: list[str | None], index: int | None, text: str,
             *, overwrite: bool = False) -> None:
    if index is None or index < 0 or index >= len(lines) or not text:
        return
    if lines[index] is None or overwrite:
        lines[index] = text.rstrip()


def split_two_line_statement(stmt: str, start_pos: int, end_pos: int) -> tuple[str, str]:
    """Apply the supplied MOVE/WRITE two-line rule with defensive bounds."""
    length = max(end_pos - start_pos, 0)
    if length <= 0 or length >= len(stmt):
        # Prefer a word boundary near the middle when positions cannot give a valid split.
        matches = list(re.finditer(r"\s+", stmt))
        if not matches:
            return stmt, ""
        cut = min(matches, key=lambda m: abs(m.start() - len(stmt) // 2)).end()
        return stmt[:cut].rstrip(), stmt[cut:].lstrip()
    return stmt[:-length].rstrip(), stmt[-length:].lstrip()

def get_paragraph_list(df: pd.DataFrame) -> list[str]:
    """
    Extract paragraphs exactly as they appear in the original
    paraList ordering captured inside node_path.

    Example:

    program_json:sectionList.0.paraList.0.paraName
    program_json:sectionList.0.paraList.1.paraName
    program_json:sectionList.0.paraList.2.paraName
    """

    paragraph_rows = df[
        df["kind"].str.lower() == "cobol_paragraph"
    ].copy()

    paragraph_rows["para_idx"] = (
        paragraph_rows["node_path"]
        .str.extract(r"paraList\.(\d+)")
        .astype(int)
    )

    paragraph_rows = paragraph_rows.sort_values(
        "para_idx",
        kind="stable"
    )

    return [
        f"{name}."
        for name in paragraph_rows["name"]
        if str(name).strip()
    ]

def get_paragraph_positions(df):
    """
    Recover paragraph order from nodePath and
    determine insertion positions from statements.

    Returns:
        [
            (line_index, "SEC-ROOT-PARA-0."),
            (line_index, "A110-READ-PARA."),
            (line_index, "A100-MOVE-DATA.")
        ]
    """

    paragraphs = df[
        df["kind"].str.lower() == "cobol_paragraph"
    ].copy()

    if paragraphs.empty:
        return []

    paragraphs["para_idx"] = (
        paragraphs["node_path"]
        .str.extract(r"paraList\.(\d+)")
        .astype(int)
    )

    paragraphs = paragraphs.sort_values(
        "para_idx",
        kind="stable"
    )

    stmt_lines = sorted(
        {
            int(v)
            for v in df.loc[
                (
                    (df["stmt_text"] != "")
                    |
                    df["kind"].isin(
                        [
                            "OPEN",
                            "STOP_RUN",
                            "ELSE",
                            "AT_END",
                            "NOT_AT_END",
                            "READNEXT"
                        ]
                    )
                )
                &
                df["start_line"].notna(),
                "start_line"
            ].tolist()
            if int(v) > 1
        }
    )

    if not stmt_lines:
        return []

    #
    # VSAMPRGM example
    #
    # para0 -> first statement group
    # para1 -> READ paragraph
    # para2 -> MOVE paragraph
    #

    placements = []

    paragraph_names = paragraphs["name"].tolist()

    if len(paragraph_names) >= 1:
        placements.append(
            (
                stmt_lines[0] - 2,
                f"{paragraph_names[0]}."
            )
        )

    readnext_row = df[
        df["kind"] == "READNEXT"
    ]

    if (
        len(paragraph_names) >= 2
        and not readnext_row.empty
    ):
        placements.append(
            (
                int(readnext_row.iloc[0]["start_line"]) - 2,
                f"{paragraph_names[1]}."
            )
        )

    after_read = df[
        df["start_line"] > (
            int(readnext_row.iloc[0]["end_line"])
            if not readnext_row.empty
            else 0
        )
    ]

    if (
        len(paragraph_names) >= 3
        and not after_read.empty
    ):
        placements.append(
            (
                int(after_read["start_line"].min()) - 2,
                f"{paragraph_names[2]}."
            )
        )

    return placements

def add_periods(lines: list[str], df: pd.DataFrame) -> list[str]:
    """Period rules:
    1. Multiline block (start_idx != end_idx): period ONLY on the last line.
    2. No period after a PERFORM statement.erwise: add a period after every (non-empty) line.
    """
    lines = ["" if line is None else line for line in lines]

    paragraph_re = re.compile(r"^[A-Z0-9-]+\.$")

    block_non_terminal_indexes = set()   # interior lines of multiline blocks
    block_last_indexes = set()           # last line of each multiline block

    # Rule 1 setup: map out multiline blocks from start_idx/end_idx
    for _, row in df.iterrows():
        start_idx = _integer(row.get("start_idx"))
        end_idx = _integer(row.get("end_idx"), start_idx)
        if start_idx is None or end_idx is None or start_idx < 0 or end_idx < 0:
            continue
        if start_idx != end_idx:
            block_last_indexes.add(end_idx)
            for idx in range(start_idx, end_idx):
                block_non_terminal_indexes.add(idx)

    for idx, line in enumerate(lines):
        if not line:
            continue

        stripped = line.strip()
        upper = stripped.upper()

        # Paragraph labels already end with '.'
        if paragraph_re.match(stripped):
            continue

        # Already has a period
        if stripped.endswith("."):
            continue

        # Rule 1a: interior line of a multiline block -> NO period
        if idx in block_non_terminal_indexes:
            continue

        # Rule 1b: last line of a multiline block -> ADD period
        if idx in block_last_indexes:
            lines[idx] = line.rstrip() + "."
            continue

        # Rule 2: no period after PERFORM
        if upper.startswith("PERFORM "):
            continue

        # Rule 3: everything else -> ADD period
        lines[idx] = line.rstrip() + "."

    return lines

# def add_periods(
#     lines: list[str],
#     df: pd.DataFrame
# ) -> list[str]:

#     lines = [
#         "" if line is None else line
#         for line in lines
#     ]

#     paragraph_re = re.compile(
#         r"^[A-Z0-9-]+\.$"
#     )

#     #
#     # Every non-terminal line of a multiline block
#     #
#     block_non_terminal_indexes = set()

#     #
#     # Last line of a multiline block
#     #
#     block_last_indexes = set()

#     for _, row in df.iterrows():

#         start_idx = _integer(
#             row.get("start_idx")
#         )

#         end_idx = _integer(
#             row.get("end_idx"),
#             start_idx
#         )

#         if (
#             start_idx is None
#             or end_idx is None
#             or start_idx < 0
#             or end_idx < 0
#         ):
#             continue

#         if start_idx != end_idx:

#             block_last_indexes.add(
#                 end_idx
#             )

#             for idx in range(
#                 start_idx,
#                 end_idx
#             ):
#                 block_non_terminal_indexes.add(
#                     idx
#                 )

#     for idx, line in enumerate(lines):

#         if not line:
#             continue

#         stripped = line.strip()
#         upper = stripped.upper()

#         #
#         # Paragraph names
#         #
#         if paragraph_re.match(stripped):
#             continue

#         #
#         # Already has period
#         #
#         if stripped.endswith("."):
#             continue

#         #
#         # Any non-terminal block line
#         #
#         if idx in block_non_terminal_indexes:
#             continue

#         #
#         # Final line of block
#         #
#         if idx in block_last_indexes:
#             lines[idx] = line.rstrip() + "."
#             continue

#         #
#         # Control statements
#         #
#         if upper == "ELSE":
#             continue

#         if upper.startswith("IF "):
#             continue

#         if upper.startswith("PERFORM "):
#             continue

#         if upper.startswith("AT END"):
#             continue

#         if upper.startswith("NOT AT END"):
#             continue

#         if upper.startswith("READ "):
#             continue

#         #
#         # END-* statements
#         #
#         if upper.startswith("END-"):
#             lines[idx] = line.rstrip() + "."
#             continue

#         #
#         # Everything else
#         #
#         lines[idx] = line.rstrip() + "."

#     return lines





FILE_DESCRIPTION_ALIASES = {
 "node_id":["node_id","node.id","id"], "kind":["kind"],
 "start_line":["start_line","StartLine","Start line","Start Line"],
 "end_line":["end_line","EndLine","End line","End Line"],
 "start_pos":["start_pos","StartPos","sPos","Start Pos"],
 "end_pos":["end_pos","EndPos","ePos","End Pos"],
 "level_no":["level_no","levelNo"], "var_name":["var_name","varName"],
 "pic_string":["pic_string","picString"], "usage":["usage"],
 "signed_flag":["signed_flag","signedFlag"], "sign_position":["sign_position","signPosition"],
 "array_flag":["array_flag","arrayFlag"], "occurs_from":["occurs_from","occursFrom"],
 "occurs_to":["occurs_to","occursTo"], "indexed_by":["indexed_by","indexedBy"],
 "depending_on":["depending_on","dependingOn"], "redefine_flag":["redefine_flag","redefineFlag"],
 "redefine_var":["redefine_var","redefineVar"], "rename_flag":["rename_flag","renameFlag"],
 "rename_var":["rename_var","renameVar"], "initial_value":["initial_value","initialValue"],
 "node_path":["node_path","nodePath","node.nodePath"]}

def normalize_file_description(df):
    lookup={_clean_header(c):c for c in df.columns}; rename={}
    for key, aliases in FILE_DESCRIPTION_ALIASES.items():
        src=next((lookup[_clean_header(a)] for a in aliases if _clean_header(a) in lookup),None)
        if src is not None: rename[src]=key
    out=df.rename(columns=rename).copy()
    for col in FILE_DESCRIPTION_ALIASES:
        if col not in out: out[col]=pd.NA
    for col in ["start_line","end_line","start_pos","end_pos","level_no"]:
        out[col]=pd.to_numeric(out[col],errors="coerce").astype("Int64")
    out["original_start_line"]=out["start_line"]; out["original_end_line"]=out["end_line"]
    out["start_line"]=out["start_line"]-1; out["end_line"]=out["end_line"]-1
    out["start_idx"]=out["start_line"]-1; out["end_idx"]=out["end_line"]-1
    return out.sort_values(["start_line","node_path"],kind="stable",na_position="last").reset_index(drop=True)

def _fd_flag(v): return _text(v).upper() in {"Y","YES","TRUE","1"}
def _fd_level(v):
    n=_integer(v); return "" if n is None else f"{n:02d}"
def _fd_positive(v):
    n=_integer(v); return "" if n is None or n <= 0 else str(n)
def _fd_tail(v):
    t=_text(v); return t.rsplit("&&&",1)[-1] if t else ""
def _fd_list_index(path,name):
    m=re.search(rf"{re.escape(name)}\.(\d+)",_text(path),re.I); return int(m.group(1)) if m else None

def build_file_data_clause(row):
    level=_fd_level(row.get("level_no")); name=_text(row.get("var_name"))
    if not level or not name: return ""
    parts=[level,name]
    rv=_text(row.get("redefine_var"))
    if _fd_flag(row.get("redefine_flag")) and rv: parts += ["REDEFINES",rv]
    rn=_text(row.get("rename_var"))
    if _fd_flag(row.get("rename_flag")) and rn: parts += ["RENAMES",rn]
    pic=_text(row.get("pic_string"))
    if pic: parts += ["PIC",pic]
    usage=_text(row.get("usage"))
    if usage: parts.append(usage.upper())
    if _fd_flag(row.get("signed_flag")):
        parts += ["SIGN IS",(_text(row.get("sign_position")) or "TRAILING").upper()]
    # lo,hi=_fd_positive(row.get("occurs_from")),_fd_positive(row.get("occurs_to"))
    # if _fd_flag(row.get("array_flag")) or lo or hi:
    #     if lo and hi and lo != hi: parts += ["OCCURS",lo,"TO",hi,"TIMES"]
    #     elif lo or hi: parts += ["OCCURS",hi or lo,"TIMES"]
    #     dep=_text(row.get("depending_on")); ind=_text(row.get("indexed_by"))
    #     if dep: parts += ["DEPENDING ON",dep]
    #     if ind: parts += ["INDEXED BY",ind]
    # --------------------------------------------------
    # OCCURS
    # --------------------------------------------------

    occurs_from = _integer(row.get("occurs_from"))
    occurs_to   = _integer(row.get("occurs_to"))

    # Treat 0 as NOT PRESENT
    if occurs_from is not None and occurs_from <= 0:
        occurs_from = None

    if occurs_to is not None and occurs_to <= 0:
        occurs_to = None

    depending_on = _text(row.get("depending_on"))
    indexed_by   = _text(row.get("indexed_by"))

    if depending_on in ("", "[]"):
        depending_on = None

    if indexed_by in ("", "[]"):
        indexed_by = None

    if occurs_from and occurs_to:
        parts.append(
            f"OCCURS {occurs_from} TO {occurs_to} TIMES"
        )

    elif occurs_to:
        parts.append(
            f"OCCURS {occurs_to} TIMES"
        )

    elif occurs_from:
        parts.append(
            f"OCCURS {occurs_from} TIMES"
        )

    if depending_on:
        parts.append(
            f"DEPENDING ON {depending_on}"
        )

    if indexed_by:
        parts.append(
            f"INDEXED BY {indexed_by}"
        )
    val=_text(row.get("initial_value"))
    if val: parts += ["VALUE",val]
    return " ".join(parts)+"."

def build_select_entries(file_df):
    records={}; ddnames={}
    for _,row in file_df.iterrows():
        i=_fd_list_index(row.get("node_path"),"FDLIST")
        if i is None: continue
        kind=_text(row.get("kind")).lower()
        if kind=="recordfile": records[i]=_fd_tail(row.get("node_id"))
        elif kind=="program_ddname": ddnames[i]=_fd_tail(row.get("node_id"))
    return [f"SELECT {records[i]} ASSIGN TO {ddnames[i]}." for i in sorted(records.keys() & ddnames.keys())]

def overlay_file_description(lines,file_df,warnings):
    rows=file_df[file_df["var_name"].map(_text)!=""].copy()
    if rows.empty: warnings.append("No file-description var_name rows found."); return lines
    max_line=int(rows["start_line"].dropna().max())
    if len(lines)<max_line: lines.extend([""]*(max_line-len(lines)))
    roots={}
    for _,r in file_df.iterrows():
        if _text(r.get("kind")).lower()=="recordfile":
            i=_fd_list_index(r.get("node_path"),"FDLIST")
            if i is not None: roots[i]=_fd_tail(r.get("node_id"))
    first=[]
    for _,r in rows.iterrows():
        idx=_integer(r.get("start_idx")); clause=build_file_data_clause(r)
        if idx is None or idx<0 or not clause: continue
        if idx>=len(lines): lines.extend([""]*(idx-len(lines)+1))
        lines[idx]=indent(r.get("start_pos"))+clause
        if _fd_level(r.get("level_no"))=="01":
            first.append(idx); root=_fd_list_index(r.get("node_path"),"symbolArray"); fd=roots.get(root)
            if fd and idx>0:
                if not lines[idx-1]: lines[idx-1]=f"      FD {fd}."
                else: warnings.append(f"FD {fd} could not be placed at physical line {idx}.")
    if first:
        pre=["ENVIRONMENT DIVISION.","INPUT-OUTPUT SECTION.","FILE-CONTROL."]
        pre += ["    "+x for x in build_select_entries(file_df)]
        pre += ["DATA DIVISION.","FILE SECTION."]
        free=[i for i in range(max(min(first)-1,0)) if not lines[i]]
        if len(free)>=len(pre):
            for i,text in zip(free[-len(pre):],pre): lines[i]=text
        else: warnings.append("Not enough blank lines to place FILE-CONTROL/FILE SECTION headers.")
    return lines


def reconstruct(df: pd.DataFrame, verbose: bool = False, file_df: pd.DataFrame | None = None) -> tuple[list[str], list[str]]:
    valid_ends = df["end_line"].dropna()
    valid_starts = df["start_line"].dropna()
    if valid_ends.empty and valid_starts.empty:
        raise ValueError("No usable StartLine/EndLine values were found.")

    max_line = int(max(valid_ends.max() if not valid_ends.empty else 0,
                       valid_starts.max() if not valid_starts.empty else 0))
    lines: list[str | None] = [None] * max_line
    warnings: list[str] = []

    grouped = {int(line): group for line, group in df.dropna(subset=["start_idx"]).groupby("start_idx", sort=False)}
    repeated = {line for line, group in grouped.items() if len(group) > 1}
    closed_if_lines: set[int] = set()

    for i, row in df.iterrows():
        start_idx = _integer(row["start_idx"])
        end_idx = _integer(row["end_idx"], start_idx)
        start_line = _integer(row["start_line"])
        end_line = _integer(row["end_line"], start_line)
        start_pos = _integer(row["start_pos"], 1) or 1
        end_pos = _integer(row["end_pos"], start_pos) or start_pos
        kind = _text(row["kind"]).upper()
        stmt = _text(row["stmt_text"])
        prefix = indent(row["start_pos"])

        if verbose and kind in {"OPEN", "READNEXT", "IF", "WRITE", "STOP_RUN"}:
            original_start = _integer(row.get("original_start_line"))
            physical_output_line = start_idx + 1 if start_idx is not None else None
            print(
                "[LINE MAP]"
                f" kind={kind}"
                f" original={original_start}"
                f" decremented={start_line}"
                f" list_index={start_idx}"
                f" physical_output_line={physical_output_line}",
                file=sys.stderr,
            )

        if (
            start_line is None
            or start_line < 1
            or start_idx is None
            or start_idx < 0
        ):
            continue

        is_repeated = start_idx in repeated

        if stmt and not is_repeated:
            if start_line == end_line:
                put_line(lines, start_idx, prefix + stmt)
            elif kind == "IF":
                put_line(lines, start_idx, prefix + stmt)
                put_line(lines, end_idx, prefix + "END-IF")
                if end_idx is not None:
                    closed_if_lines.add(end_idx)
            elif kind in {"MOVE", "WRITE"} and end_line == start_line + 1:
                first, second = split_two_line_statement(stmt, start_pos, end_pos)
                put_line(lines, start_idx, prefix + first)
                put_line(lines, end_idx, prefix + second)
            # READNEXT and other multiline statements are handled after child rows.
            continue

        if is_repeated:
            if kind == "OPEN":
                filename = _text(row["file_name"])
                mode = _text(row["operating_mode"]).upper()
                if filename and mode:
                    put_line(lines, start_idx, prefix + f"OPEN {mode} {filename}")
                else:
                    warnings.append(f"Line {start_line}: OPEN is missing fileName or operatingMode")
            elif kind == "STOP_RUN":
                put_line(lines, start_idx, prefix + "STOP RUN")
            elif kind == "ELSE":
                put_line(lines, start_idx, prefix + "ELSE")
            elif kind in {"AT_END", "NOT_AT_END"}:
                siblings = grouped.get(start_idx, pd.DataFrame())
                sibling_stmt = next((_text(v) for v in siblings.get("stmt_text", []) if _text(v)), "")
                phrase = "AT END" if kind == "AT_END" else "NOT AT END"
                put_line(lines, start_idx, prefix + phrase + (" " + sibling_stmt if sibling_stmt else ""), overwrite=True)
            elif stmt:
                # Preserve executable child statements on duplicate lines unless a block rule owns the line.
                if kind not in {"AT_END", "NOT_AT_END"}:
                    put_line(lines, start_idx, prefix + stmt)
            elif kind not in {"AT_END", "NOT_AT_END"}:
                warnings.append(f"Line {start_line}: duplicate kind {kind or '<blank>'} was not handled")
        else:
            if kind == "OPEN":
                filename = _text(row["file_name"])
                mode = _text(row["operating_mode"]).upper()
                put_line(lines, start_idx, prefix + f"OPEN {mode} {filename}".strip())
            elif kind == "STOP_RUN":
                put_line(lines, start_idx, prefix + "STOP RUN")
            elif kind == "ELSE":
                put_line(lines, start_idx, prefix + "ELSE")
            elif stmt and start_line == end_line:
                put_line(lines, start_idx, prefix + stmt)

    # Second pass from the pseudocode: recover the READNEXT header before its first child line.
    for _, row in df.iterrows():
        kind = _text(row["kind"]).upper()
        stmt = _text(row["stmt_text"])
        start_idx = _integer(row["start_idx"])
        end_idx = _integer(row["end_idx"], start_idx)
        start_line = _integer(row["start_line"])
        if (
            kind != "READNEXT"
            or not stmt
            or start_idx is None
            or start_idx < 0
            or end_idx == start_idx
            or start_line is None
            or start_line < 1
        ):
            continue
        child_idx = start_idx + 1
        child = lines[child_idx] if 0 <= child_idx < len(lines) else None
        if child:
            child_stripped = child.strip()
            pos = stmt.find(child_stripped)
            header = stmt[:pos].rstrip() if pos >= 0 else ""
            if header:
                put_line(lines, start_idx, indent(row["start_pos"]) + header, overwrite=True)
        if end_idx is not None:
            put_line(lines, end_idx, indent(row["start_pos"]) + "END-READ")
    # --------------------------------------------------
    # Paragraph recovery
    # --------------------------------------------------

    # ParaList = get_paragraph_list(df)
    # # print(ParaList)

    # for i in range(len(lines)):
    #     if not ParaList:
    #         break

    #     if lines[i] is None:
    #         lines[i] = ParaList.pop(0)
    # # Paragraph recovery. First use inferred source boundaries, then conservative blank slots.
    # paragraph_rows = df[(df["kind"].str.lower() == "cobol_paragraph") &
    #                     (df["name"].str.upper() != "SEC-ROOT-PARA-0")].copy()
    # ordered_names = [name + "." for name in paragraph_rows.sort_values(
    #     ["seq_no", "node_path"], kind="stable")["name"].tolist() if name]

    # placed_names: set[str] = set()
    # for index, name in infer_paragraph_lines(df):
    #     if 0 <= index < len(lines) and lines[index] is None:
    #         lines[index] = name
    #         placed_names.add(name)

    # remaining = [name for name in ordered_names if name not in placed_names]
    # for index in range(1, len(lines)):
    #     if not remaining:
    #         break
    #     if lines[index] is None:
    #         previous_filled = index > 0 and lines[index - 1] is not None
    #         next_filled = index + 1 < len(lines) and lines[index + 1] is not None
    #         if next_filled and not previous_filled:
    #             lines[index] = remaining.pop(0)

    # Do not overwrite generated END-IF lines; record this only for diagnostics.

    # --------------------------------------------------
    # Paragraph placement
    # --------------------------------------------------

    for line_idx, para_name in get_paragraph_positions(df):

        if line_idx < 0:
            line_idx = 0

        while (
            line_idx < len(lines)
            and lines[line_idx] is not None
        ):
            line_idx += 1

        if line_idx < len(lines):
            
            lines[line_idx] = para_name
            # print(para_name)

    if file_df is not None:
        lines = overlay_file_description(lines, file_df, warnings)
    #period check
    lines = add_periods(lines, df)
    
    if verbose and closed_if_lines:
        warnings.append("Generated END-IF at source line(s): " + ", ".join(str(i + 1) for i in sorted(closed_if_lines)))

    return [(line if line is not None else "") for line in lines], warnings


def write_cobol(lines: list[str], output: Path, keep_trailing_blank: bool = False) -> None:
    if not keep_trailing_blank:
        while lines and not lines[-1]:
            lines.pop()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Reconstruct available COBOL lines from a KDM graph CSV/XLSX export."
    )
    parser.add_argument("input", type=Path, help="Input CSV/XLSX file")
    parser.add_argument("--file-description", type=Path, help="File-description XLSX/CSV metadata")
    parser.add_argument("--file-sheet", default=0, help="File-description sheet (default: 0)")
    parser.add_argument("-o", "--output", type=Path, help="Output COB/CBL file")
    parser.add_argument("--sheet", default=0, help="Excel sheet name or zero-based index (default: 0)")
    parser.add_argument("--keep-trailing-blank", action="store_true", help="Retain blank lines through maximum EndLine")
    parser.add_argument("-v", "--verbose", action="store_true", help="Print reconstruction warnings")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if not args.input.exists():
        print(f"Error: input file not found: {args.input}", file=sys.stderr)
        return 2

    output = args.output or args.input.with_suffix(".cob")
    sheet: str | int = int(args.sheet) if str(args.sheet).isdigit() else args.sheet

    try:
        raw = read_table(args.input, sheet=sheet)
        df = normalize_columns(raw)
        file_df = None
        if args.file_description:
            if not args.file_description.exists():
                raise FileNotFoundError(f"File-description input not found: {args.file_description}")
            file_sheet = int(args.file_sheet) if str(args.file_sheet).isdigit() else args.file_sheet
            file_df = normalize_file_description(read_table(args.file_description, sheet=file_sheet))
        lines, warnings = reconstruct(df, verbose=args.verbose, file_df=file_df)
        write_cobol(lines, output, keep_trailing_blank=args.keep_trailing_blank)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"COBOL reconstruction written to: {output}")
    represented = sum(bool(line.strip()) for line in lines)
    print(f"Represented lines: {represented} of {len(lines)}")
    if args.verbose:
        for message in warnings:
            print(f"Warning: {message}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
