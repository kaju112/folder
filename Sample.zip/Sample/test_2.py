import pandas as pd
import argparse


def is_null(v):
    if pd.isna(v):
        return True

    if isinstance(v, str):
        return v.strip().lower() in ("", "null", "none", "[]")

    return False


def clean(v):
    if is_null(v):
        return None

    return str(v).strip()


def extract_name(value):
    """
    Converts:
        StorableUnit&&&VSAMPRGM&&&OEMP -> OEMP
        ItemUnit&&&VSAMPRGM&&&IN1      -> IN1
    """
    value = clean(value)

    if not value:
        return None

    if "&&&" in value:
        return value.split("&&&")[-1]

    return value


def format_level(level):
    """
    1.0  -> 01
    5.0  -> 05
    10.0 -> 10
    77.0 -> 77
    88.0 -> 88
    """
    if is_null(level):
        return None

    try:
        level = int(float(level))
        return f"{level:02d}"
    except Exception:
        return str(level).strip()


def format_number(value):
    """
    3.0   -> 3
    12.0  -> 12
    100.0 -> 100
    """
    if is_null(value):
        return None

    try:
        return str(int(float(value)))
    except Exception:
        return str(value).strip()


def load_metadata(xlsx_file):

    df = pd.read_excel(xlsx_file)

    df.columns = [c.strip().lower() for c in df.columns]

    #
    # start_line -> start_line - 1
    #
    if "start_line" in df.columns:

        df["start_line"] = pd.to_numeric(
            df["start_line"],
            errors="coerce"
        )

        df["original_start_line"] = (
            df["start_line"].copy()
        )

        df["start_line"] = (
            df["start_line"] - 1
        )

    #
    # end_line -> end_line - 1
    #
    if "end_line" in df.columns:

        df["end_line"] = pd.to_numeric(
            df["end_line"],
            errors="coerce"
        )

        df["original_end_line"] = (
            df["end_line"].copy()
        )

        df["end_line"] = (
            df["end_line"] - 1
        )

    #
    # NULL safe validation
    #
    if (
        "start_line" in df.columns
        and "original_start_line" in df.columns
    ):

        start_mask = (
            df["original_start_line"].notna()
        )

        bad_start_rows = df.loc[
            start_mask &
            (
                df["start_line"]
                !=
                df["original_start_line"] - 1
            )
        ]

        if not bad_start_rows.empty:

            print(
                "\nFAILED START_LINE VALIDATION\n"
            )

            print(
                bad_start_rows[
                    [
                        "node_id",
                        "original_start_line",
                        "start_line"
                    ]
                ]
            )

            raise ValueError(
                "start_line decrement validation failed"
            )

    if (
        "end_line" in df.columns
        and "original_end_line" in df.columns
    ):

        end_mask = (
            df["original_end_line"].notna()
        )

        bad_end_rows = df.loc[
            end_mask &
            (
                df["end_line"]
                !=
                df["original_end_line"] - 1
            )
        ]

        if not bad_end_rows.empty:

            print(
                "\nFAILED END_LINE VALIDATION\n"
            )

            print(
                bad_end_rows[
                    [
                        "node_id",
                        "original_end_line",
                        "end_line"
                    ]
                ]
            )

            raise ValueError(
                "end_line decrement validation failed"
            )

    return df


def build_select_entries(df):

    lines = []

    record_files = df[
        df["kind"] == "RecordFile"
    ]

    ddnames = df[
        df["kind"] == "program_ddname"
    ]

    count = min(
        len(record_files),
        len(ddnames)
    )

    for i in range(count):

        file_name = extract_name(
            record_files.iloc[i]["node_id"]
        )

        ddname = extract_name(
            ddnames.iloc[i]["node_id"]
        )

        if file_name and ddname:

            lines.append(
                f"SELECT {file_name} ASSIGN TO {ddname}."
            )

    return lines


def build_data_line(row):

    parts = []

    level_no = format_level(
        row.get("level_no")
    )

    var_name = clean(
        row.get("var_name")
    )

    if level_no:
        parts.append(level_no)

    if var_name:
        parts.append(var_name)

    #
    # REDEFINES
    #
    redefine_flag = clean(
        row.get("redefine_flag")
    )

    redefine_var = clean(
        row.get("redefine_var")
    )

    if redefine_flag == "Y" and redefine_var:

        parts.append(
            f"REDEFINES {redefine_var}"
        )

    #
    # PIC
    #
    pic_string = clean(
        row.get("pic_string")
    )

    if pic_string:

        parts.append(
            f"PIC {pic_string}"
        )

    #
    # USAGE
    #
    usage = clean(
        row.get("usage")
    )

    if usage:

        parts.append(
            f"USAGE {usage}"
        )

    #
    # SIGN
    #
    signed_flag = clean(
        row.get("signed_flag")
    )

    sign_position = clean(
        row.get("sign_position")
    )

    if signed_flag == "Y":

        if sign_position:

            parts.append(
                f"SIGN IS {sign_position}"
            )

        else:

            parts.append(
                "SIGN IS TRAILING"
            )

    #
    # OCCURS
    #
    array_flag = clean(
        row.get("array_flag")
    )

    occurs_from = format_number(
        row.get("occurs_from")
    )

    occurs_to = format_number(
        row.get("occurs_to")
    )

    depending_on = clean(
        row.get("depending_on")
    )

    if array_flag == "Y":

        if occurs_to:

            parts.append(
                f"OCCURS {occurs_from} TO {occurs_to} TIMES"
            )

        elif occurs_from:

            parts.append(
                f"OCCURS {occurs_from} TIMES"
            )

        if depending_on:

            parts.append(
                f"DEPENDING ON {depending_on}"
            )

    #
    # VALUE
    #
    initial_value = clean(
        row.get("initial_value")
    )

    if initial_value:

        parts.append(
            f"VALUE {initial_value}"
        )

    return " ".join(parts) + "."


def indentation(start_pos):

    if is_null(start_pos):
        return ""

    try:
        start_pos = int(
            float(start_pos)
        )
    except Exception:
        return ""

    indent = max(
        0,
        start_pos - 7
    )

    return " " * indent


def build_fd_lines(df):

    symbol_rows = df[
        df["var_name"].notna()
    ].copy()

    symbol_rows["start_line"] = pd.to_numeric(
        symbol_rows["start_line"],
        errors="coerce"
    )

    symbol_rows = symbol_rows[
        symbol_rows["start_line"].notna()
    ]

    if symbol_rows.empty:
        return {}

    placed_lines = {}

    for _, row in symbol_rows.iterrows():

        start_line = row.get(
            "start_line"
        )

        if pd.isna(start_line):
            continue

        #
        # decremented line number
        #
        line_no = int(start_line)

        var_name = clean(
            row.get("var_name")
        )

        if not var_name:
            continue

        level_no = format_level(
            row.get("level_no")
        )

        indent = indentation(
            row.get("start_pos")
        )

        if level_no == "01":

            placed_lines[line_no] = (
                f"01 {var_name}."
            )

        else:

            placed_lines[line_no] = (
                indent +
                build_data_line(row)
            )

    return placed_lines


def build_program(df):

    #
    # Find largest decremented line number
    #
    valid_lines = df[
        df["start_line"].notna()
    ]

    max_line = int(
        valid_lines["start_line"].max()
    )

    output = [""] * (
        max_line + 50
    )

    #
    # Header section
    #
    output[0] = "FILE-CONTROL."

    select_entries = build_select_entries(df)

    current_line = 2

    for entry in select_entries:

        output[current_line] = entry

        current_line += 1

    output[10] = "FILE SECTION."

    #
    # Place variables at exact
    # decremented start_line
    #
    fd_lines = build_fd_lines(df)

    for line_no, text in fd_lines.items():

        if line_no >= len(output):

            output.extend(
                [""] * (
                    line_no - len(output) + 1
                )
            )

        output[line_no] = text

    return output


def write_output(
    lines,
    output_file
):

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as fp:

        fp.write(
            "\n".join(lines)
        )


def main():

    parser = argparse.ArgumentParser(
        description=
        "Reconstruct COBOL File Section from XLSX metadata"
    )

    parser.add_argument(
        "xlsx",
        help="Metadata Excel"
    )

    parser.add_argument(
        "-o",
        "--output",
        default="file_section.cbl"
    )

    args = parser.parse_args()

    df = load_metadata(
        args.xlsx
    )

    lines = build_program(
        df
    )

    #
    # Debug actual physical placement
    #
    print("\n===== GENERATED LINE MAP =====\n")

    for i, line in enumerate(lines):

        if line.strip():

            print(
                f"{i:03d}: {line}"
            )

    write_output(
        lines,
        args.output
    )

    print(
        f"\nGenerated: {args.output}"
    )


if __name__ == "__main__":
    main()