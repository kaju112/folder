# VSAMPRGM Program Documentation

## 1. Overview

`VSAMPRGM` reads employee records sequentially from the input file `OEMP`, transforms selected fields, and writes records to the indexed output file `VSAMOFF`.

The program performs these main operations:

1. Opens `OEMP` as a sequential input file.
2. Opens `VSAMOFF` in `EXTEND` mode.
3. Reads `OEMP` until end-of-file.
4. Converts rating and salary values into the formats declared for `VSAMOFF`.
5. Copies employee identification, designation, date of joining, and selected attendance data.
6. Writes an output record.
7. Closes both files and terminates.

> Source note: The header says this is expanded code produced by TCS MasterCraft on Friday, July 31, 2026.

---

## 2. Program Identity

```cobol
PROGRAM-ID. VSAMPRGM.
```

The COBOL program name is `VSAMPRGM`.

---

## 3. File Definitions

### 3.1 Input file: OEMP

```cobol
SELECT OEMP ASSIGN TO IN1
    ORGANIZATION IS SEQUENTIAL
    ACCESS MODE IS SEQUENTIAL
    FILE STATUS IS WS-FS.
```

`OEMP` is a sequential input file associated with the external logical name `IN1`.

- **Organization:** Sequential
- **Access mode:** Sequential
- **File-status variable:** `WS-FS`
- **Record name:** `OEMP-REC`

### OEMP record layout

| Field | Picture | Purpose |
|---|---:|---|
| `O-EMPID` | `X(5)` | Employee identifier |
| `O-DESIGNATION` | `X(10)` | Employee designation |
| `O-RATING` | `X(3)` | Rating represented as three display characters |
| `O-SALARY` | `9(2)V9(2)` | Four-digit display salary with an implied decimal point |
| `O-DOJ-YEAR` | `X(4)` | Joining year |
| `O-DOJ-MONTH` | `X(2)` | Joining month |
| `0-DOJ-DAY` | `X(2)` | Joining day; the first character is digit zero in the supplied source |
| `O-DAYS-WORKED` | `9(2)` | Days worked for each year and month occurrence |
| `FILLER` | `X(50)` | Unused input padding |

The attendance structure contains:

- 3 year occurrences
- 12 month occurrences per year
- 2 digits for days worked per month

Therefore, attendance occupies `3 x 12 x 2 = 72` display bytes.

The logical input record length is 152 bytes:

```text
5 + 10 + 3 + 4 + 8 + 72 + 50 = 152
```

### 3.2 Output file: VSAMOFF

```cobol
SELECT VSAMOFF ASSIGN TO OUT1
    ORGANIZATION IS INDEXED
    ACCESS MODE IS SEQUENTIAL
    RECORD KEY IS V-EMPID
    FILE STATUS IS WS-FS1.
```

`VSAMOFF` is declared as an indexed file associated with `OUT1`.

- **Organization:** Indexed
- **Access mode:** Sequential
- **Record key:** `V-EMPID`
- **File-status variable:** `WS-FS1`
- **Record name:** `VSAMOFF-DETAILS`

### VSAMOFF record layout

| Field | Picture/usage | Purpose |
|---|---:|---|
| `V-EMPID` | `X(5)` | Indexed file record key |
| `V-DESIGNATION` | `X(10)` | Employee designation |
| `V-RATING` | `S9(2)` with leading separate sign | Signed two-digit rating |
| `V-SALARY` | `99V99 COMP-3` | Packed-decimal salary |
| `V-DOJ-YEAR` | `X(4)` | Joining year |
| `V-DOJ-MONTH` | `X(2)` | Joining month |
| `V-DOJ-DAY` | `X(2)` | Joining day |
| `V-DAYS-WORKED` | `9(2)` | Days worked by year and month |
| `FILLER` | `X(51)` | Output padding |

`V-RATING` occupies three bytes because it contains two digits and a separate sign. `V-SALARY` occupies three packed-decimal bytes. The intended output record length is also 152 bytes.

---

## 4. Working-Storage

### 4.1 Generated system variables

`SYSTEM-VARIABLES` contains fields reserved for generated runtime support, including:

- IMS database status information
- return code handling
- debugging information
- sort configuration and return status
- exception status, file, and location

No statement in the shown Procedure Division directly uses these fields.

### 4.2 WS-EMP-OFF

`WS-EMP-OFF` is a working-storage employee layout similar to `OEMP-REC`. However, the shown program does not move `OEMP-REC` into `WS-EMP-OFF`. Consequently, the displays of `WS-EMP-OFF`, `WS-EMPID`, `WS-DESIGNATION`, `WS-RATING`, `WS-SALARY`, and `WS-DOJ` do not display the input record unless omitted generated code initializes or populates this area.

### 4.3 Calculation and control fields

| Field | Initial value | Use |
|---|---:|---|
| `WS-ALLOWANCES` | `90.10` | Added to input salary |
| `WS-DEDUCTIONS` | Undefined | Declared but not used |
| `WS-FS` | Undefined | Input file status |
| `WS-FS1` | Undefined | Output file status |
| `WS-EOF` | `N` | End-of-file loop control |
| `WS-TEMP` | Undefined | Numeric rating conversion field |
| `WS-SIGNCHECK` | Undefined | Holds the first character of `O-RATING` |
| `WS-DEMO` | Literal text | Declared but not used |
| `WS-STRING-LENGTH` | Undefined | Receives the length of `V-DESIGNATION` |

---

## 5. Main Processing Flow

### 5.1 Initialization

```cobol
OPEN INPUT OEMP.
OPEN EXTEND VSAMOFF.
```

The program opens the sequential input file and attempts to open the indexed output file in `EXTEND` mode.

It then displays both file-status values:

```cobol
DISPLAY ' FILE STATUS FOR PS ' WS-FS.
DISPLAY ' FILE STATUS FOR VSAM ' WS-FS1.
```

The expected successful file status is normally `00`. The program only displays the statuses and does not branch when an open fails.

### 5.2 Read loop

```cobol
PERFORM A110-READ-PARA UNTIL WS-EOF = 'Y'
```

`A110-READ-PARA` is called repeatedly. The loop stops after a read reaches end-of-file and moves `Y` to `WS-EOF`.

### 5.3 Termination

```cobol
CLOSE OEMP.
CLOSE VSAMOFF.
STOP RUN.
```

After the loop finishes, both files are closed and the program terminates.

---

## 6. A110-READ-PARA

```cobol
READ OEMP NEXT RECORD
    AT END
        MOVE 'Y' TO WS-EOF
        DISPLAY ' WS-EOF ' WS-EOF
    NOT AT END
        PERFORM A100-MOVE-DATA
        DISPLAY ' WS-EOF ' WS-EOF
END-READ.
```

This paragraph reads one input record.

### AT END path

When no further input record is available:

1. `WS-EOF` becomes `Y`.
2. The program displays the end-of-file flag.
3. Control returns to the main loop.
4. The loop condition is checked and processing ends.

### NOT AT END path

When a record is read successfully:

1. `A100-MOVE-DATA` is performed.
2. The end-of-file flag, normally still `N`, is displayed.
3. Control returns to the loop for the next record.

---

## 7. A100-MOVE-DATA

This paragraph transforms the current record and writes an output record.

### 7.1 Working-storage displays

The paragraph initially displays `WS-EMP-OFF` and its subordinate fields. These values are not populated by the shown code, so they are independent of the record just read.

### 7.2 Employee ID

```cobol
MOVE O-EMPID TO V-EMPID.
```

The input employee ID becomes the output record key. For an indexed file, keys usually need to satisfy the dataset's uniqueness and ordering requirements.

### 7.3 Designation

```cobol
MOVE O-DESIGNATION TO V-DESIGNATION.
```

The ten-character designation is copied without conversion.

### 7.4 Rating conversion

```cobol
MOVE O-RATING(1:1) TO WS-SIGNCHECK.
MOVE O-RATING TO WS-TEMP.
IF WS-SIGNCHECK = '-'
    COMPUTE V-RATING = -1 * WS-TEMP
ELSE
    MOVE WS-TEMP TO V-RATING
END-IF.
```

The intended logic is:

1. Examine the first character of the three-character input rating.
2. Convert the input rating to numeric form using `WS-TEMP`.
3. If the first character is `-`, make `V-RATING` negative.
4. Otherwise, copy the positive value.

This conversion needs validation. Moving a value such as `-05` directly to unsigned `PIC 9(3)` can cause invalid numeric data or a runtime data exception, depending on the compiler and runtime options. A safer implementation should separately parse the sign and the digit positions.

### 7.5 Salary calculation and conversion

```cobol
COMPUTE O-SALARY = O-SALARY + WS-ALLOWANCES.
IF O-SALARY EQUAL ZEROES
    DISPLAY 'SALARY SHOULD HAVE VALUE'
ELSE
    MOVE O-SALARY TO V-SALARY
    DISPLAY 'V-SALARY      ' V-SALARY
END-IF.
```

The program adds `90.10` to the input salary and stores the result back into `O-SALARY`. If the result is not zero, it is converted from display numeric to packed decimal and moved to `V-SALARY`.

Important points:

- `O-SALARY` can represent only `00.00` through `99.99`.
- Adding `90.10` can exceed the receiving field's capacity.
- There is no `ON SIZE ERROR` clause.
- The original input buffer is modified by the calculation.

### 7.6 Date of joining

```cobol
MOVE O-DOJ TO V-DOJ.
```

The complete eight-character date group is copied from input to output as `YYYYMMDD`. The source input day field is named `0-DOJ-DAY`, with zero, but the group move still copies its bytes correctly.

### 7.7 Attendance update

```cobol
MOVE 21 TO V-DAYS-WORKED(1, 5).
```

This sets the fifth month of the first attendance year to 21 days. Because the rest of the output attendance table is not copied from the input record in the shown logic, its remaining occurrences retain their previous or initial contents.

### 7.8 Designation class test

```cobol
IF V-DESIGNATION NOT NUMERIC
    DISPLAY 'DESIGNATION IS NOT NUMERIC'
END-IF.
```

Since a designation is commonly alphabetic or alphanumeric, the message is likely to be displayed for normal designation values. If the objective is validation, an `ALPHABETIC`, `ALPHABETIC-LOWER`, `ALPHABETIC-UPPER`, or project-specific test may better express the business rule.

### 7.9 Length calculation

```cobol
MOVE FUNCTION LENGTH V-DESIGNATION
  TO WS-STRING-LENGTH.
```

`FUNCTION LENGTH` returns the declared length of `V-DESIGNATION`, which is 10. It does not calculate the number of non-space characters in the current value.

### 7.10 Output write

```cobol
WRITE VSAMOFF-DETAILS FROM OEMP-REC
    AFTER ADVANCING 2 LINES.
```

`FROM OEMP-REC` means the runtime moves the complete input record bytes into `VSAMOFF-DETAILS` immediately before writing. This can overwrite values previously placed in `V-EMPID`, `V-RATING`, `V-SALARY`, `V-DOJ`, and `V-DAYS-WORKED`.

This is the most important flow issue in the supplied code. If the transformed `V-*` fields are intended to be written, the statement should normally write `VSAMOFF-DETAILS` without `FROM OEMP-REC`.

`AFTER ADVANCING 2 LINES` is a printer-oriented sequential-file phrase. Its use with an indexed VSAM-style file may not be accepted or meaningful in the target compiler/runtime.

---

## 8. Flowchart

```mermaid
flowchart TD
    A([Start VSAMPRGM]) --> B[Open OEMP as INPUT]
    B --> C[Open VSAMOFF as EXTEND]
    C --> D[Display WS-FS and WS-FS1]
    D --> E{WS-EOF = Y?}
    E -- Yes --> Z[Close OEMP and VSAMOFF]
    Z --> ZZ([Stop Run])
    E -- No --> F[Read next OEMP record]
    F --> G{End of file?}
    G -- Yes --> H[Move Y to WS-EOF]
    H --> I[Display WS-EOF]
    I --> E
    G -- No --> J[Perform A100-MOVE-DATA]
    J --> K[Copy employee ID and designation]
    K --> L[Inspect and convert rating]
    L --> M[Add allowance to salary]
    M --> N{Salary equals zero?}
    N -- Yes --> O[Display salary warning]
    N -- No --> P[Move salary to packed V-SALARY]
    O --> Q[Copy date of joining]
    P --> Q
    Q --> R[Set year 1 month 5 attendance to 21]
    R --> S[Validate designation and calculate declared length]
    S --> T[Display transformed fields]
    T --> U[Write output record]
    U --> V[Display WS-EOF]
    V --> E
```

---

## 9. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Main as Main Procedure
    participant Input as OEMP Sequential File
    participant Transform as A100-MOVE-DATA
    participant Output as VSAMOFF Indexed File

    Main->>Input: OPEN INPUT OEMP
    Main->>Output: OPEN EXTEND VSAMOFF
    Main->>Main: Display WS-FS and WS-FS1

    loop Until WS-EOF = Y
        Main->>Input: READ NEXT RECORD
        alt Record available
            Input-->>Main: OEMP-REC
            Main->>Transform: PERFORM A100-MOVE-DATA
            Transform->>Transform: Copy ID and designation
            Transform->>Transform: Convert signed rating
            Transform->>Transform: Add 90.10 allowance
            Transform->>Transform: Convert salary to COMP-3
            Transform->>Transform: Copy DOJ
            Transform->>Transform: Set attendance (1,5) to 21
            Transform->>Output: WRITE VSAMOFF-DETAILS FROM OEMP-REC
            Output-->>Transform: WS-FS1 updated
            Transform-->>Main: Return
        else End of file
            Input-->>Main: AT END
            Main->>Main: MOVE Y TO WS-EOF
        end
    end

    Main->>Input: CLOSE OEMP
    Main->>Output: CLOSE VSAMOFF
    Main->>Main: STOP RUN
```

---

## 10. Data Mapping

| Input source | Intended output | Transformation |
|---|---|---|
| `O-EMPID` | `V-EMPID` | Direct move |
| `O-DESIGNATION` | `V-DESIGNATION` | Direct move |
| `O-RATING` | `V-RATING` | Sign inspection and numeric conversion |
| `O-SALARY` | `V-SALARY` | Add `WS-ALLOWANCES`, then convert display to COMP-3 |
| `O-DOJ` | `V-DOJ` | Group move |
| No copied source | `V-DAYS-WORKED(1,5)` | Hard-coded value 21 |
| Input filler | Output filler | No explicit mapping |

The final `WRITE ... FROM OEMP-REC` conflicts with this intended mapping because it copies raw input bytes over the output record before the write.

---

## 11. File Status Handling

The program uses separate two-digit status fields:

- `WS-FS` for `OEMP`
- `WS-FS1` for `VSAMOFF`

The statuses are displayed after file open, but they are not checked after `READ`, `WRITE`, or `CLOSE`. Robust processing should evaluate the relevant status after each file operation and handle expected and unexpected values explicitly.

For the indexed output file, duplicate or out-of-sequence keys are especially important to handle because `V-EMPID` is the record key.

---

## 12. Key Issues and Recommended Corrections

### 12.1 Output record is overwritten

Current statement:

```cobol
WRITE VSAMOFF-DETAILS FROM OEMP-REC
    AFTER ADVANCING 2 LINES.
```

Recommended intent:

```cobol
WRITE VSAMOFF-DETAILS
```

This preserves the transformed `V-*` fields.

### 12.2 Attendance table is not copied

Before applying a month-specific override, copy the input table to the output table, for example through compatible group-level fields or nested `PERFORM VARYING` loops. Then set the required occurrence.

### 12.3 Negative rating parsing is unsafe

Do not move a character value containing `-` into unsigned numeric `WS-TEMP`. Parse the sign and numeric portion separately. The exact substring depends on whether the source format is `-05`, `+05`, or unsigned `005`.

### 12.4 Salary can overflow

`O-SALARY` has only two integer digits. Add an intermediate field with enough capacity and use `ON SIZE ERROR`.

### 12.5 Input record is modified

The salary calculation changes `O-SALARY` inside `OEMP-REC`. Prefer calculating into a working numeric field or directly into a sufficiently large output/intermediate field.

### 12.6 WS-EMP-OFF is displayed before population

Either move `OEMP-REC` to `WS-EMP-OFF` before displaying it or display the `O-*` input fields directly.

### 12.7 Designation validation does not match the field meaning

`V-DESIGNATION NOT NUMERIC` is expected to be true for normal text designations. Replace it with a validation rule that matches the accepted designation format.

### 12.8 Length function does not trim spaces

`FUNCTION LENGTH V-DESIGNATION` returns 10. If the desired result is content length, trailing spaces must be removed or located before calculating the effective length.

### 12.9 Output open mode must match the indexed-file implementation

Confirm whether the target compiler supports `OPEN EXTEND` for the indexed organization. Some environments require `OUTPUT` for creation or `I-O` for adding and updating records.

### 12.10 Printer advancing phrase is inappropriate

Remove `AFTER ADVANCING 2 LINES` from an indexed data-file write unless a specific compiler extension explicitly requires it.

### 12.11 Duplicate data-name

The source declares both a group and its child as `PARAM-OBJECT`:

```cobol
01 PARAM-OBJECT.
    05 PARAM-OBJECT PIC X(2).
```

Rename one of them to avoid ambiguity and possible compilation failure, for example:

```cobol
01 PARAM-OBJECT-AREA.
    05 PARAM-OBJECT PIC X(2).
```

### 12.12 Typographical field name

`0-DOJ-DAY` starts with digit zero, whereas the output field is `V-DOJ-DAY`. Rename the input field to `O-DOJ-DAY` for consistency if the generated-source rules permit modification.

---

## 13. Simplified Pseudocode

```text
open input employee file
open indexed output file
show open statuses

while end-of-file has not been reached
    read next employee record

    if end-of-file
        set EOF flag
    else
        copy employee ID
        copy designation
        convert rating to signed numeric
        add allowance to salary

        if resulting salary is zero
            display warning
        else
            convert salary to packed decimal
        end-if

        copy date of joining
        set attendance for year 1, month 5 to 21
        validate designation
        get declared designation length
        display output fields
        write output record
    end-if
end-while

close files
stop
```

---

## 14. Expected External Runtime Mapping

The COBOL source uses logical assignments rather than physical paths:

```text
IN1  -> OEMP input dataset/file
OUT1 -> VSAMOFF indexed dataset/file
```

The JCL, runtime configuration, environment variables, or compiler-specific file mapping must associate `IN1` and `OUT1` with actual files. Those mappings are not present in the supplied source.

---

## 15. Summary

`VSAMPRGM` is intended to migrate employee data from a 152-byte sequential record into a 152-byte indexed record while converting rating and salary representations. Its high-level loop is straightforward, but the final `WRITE ... FROM OEMP-REC` currently defeats much of the transformation logic by replacing the prepared output area with raw input bytes. Rating parsing, salary overflow, attendance initialization, file-status handling, and indexed-file write semantics should also be corrected before the program is relied upon for production data conversion.
