












































































































002400 PROCEDURE DIVISION.
           OPEN INPUT OEMP.
           OPEN EXTEND VSAMOFF.
           DISPLAY ' FILE STATUS FOR PS ' WS-FS.
           DISPLAY ' FILE STATUS FOR VSAM ' WS-FS1.
           PERFORM A110-READ-PARA UNTIL WS-EOF = 'Y'
           CLOSE OEMP.
           CLOSE VSAMOFF.
           STOP RUN.
002630 A110-READ-PARA.
           READ OEMP NEXT RECORD
           AT END MOVE 'Y' TO WS-EOF
           DISPLAY ' WS-EOF ' WS-EOF
           NOT AT END PERFORM A100-MOVE-DATA
           DISPLAY ' WS-EOF ' WS-EOF
           END-READ.
       A100-MOVE-DATA.
                DISPLAY WS-EMP-OFF.
                DISPLAY ' WS-EMPID ' WS-EMPID.
                DISPLAY ' WS-DESIGNATION' WS-DESIGNATION.
                DISPLAY ' WS-RATING ' WS-RATING.
                DISPLAY ' WS-SALARY ' WS-SALARY.
                DISPLAY ' WS-DOJ  ' WS-DOJ.
                MOVE O-EMPID TO V-EMPID.
                DISPLAY 'V-EMPID ' V-EMPID.
                MOVE O-DESIGNATION TO V-DESIGNATION.
                DISPLAY 'V-DESIGNATION ' V-DESIGNATION.
                DISPLAY ' WS-RATING ' O-RATING.
                MOVE O-RATING(1:1) TO WS-SIGNCHECK.
                DISPLAY ' O-RATING(1:1) ' O-RATING(1:1).
                DISPLAY ' WS-SIGNCHECK   ' WS-SIGNCHECK.
                MOVE O-RATING TO WS-TEMP.
                DISPLAY ' WS-TEMP ' WS-TEMP.
                IF WS-SIGNCHECK = '-'
                   COMPUTE V-RATING = -1 * WS-TEMP
                ELSE
                   MOVE WS-TEMP TO V-RATING
                END-IF.
                DISPLAY 'V-RATING      ' V-RATING.
                COMPUTE O-SALARY = O-SALARY + WS-ALLOWANCES.
                IF O-SALARY EQUAL ZEROES
                   DISPLAY 'SALARY SHOULD HAVE VALUE'
                ELSE
                   MOVE O-SALARY TO V-SALARY
                   DISPLAY 'V-SALARY      ' V-SALARY
                END-IF.
                MOVE O-DOJ   TO V-DOJ.
                MOVE 21 TO V-DAYS-WORKED(1, 5).
                IF V-DESIGNATION NOT NUMERIC
                   DISPLAY 'DESIGNATION IS NOT NUMERIC'
                END-IF.
                MOVE FUNCTION LENGTH V-DESIGNATION
                TO WS-STRING-LENGTH.
                DISPLAY 'V-DOJ         ' V-DOJ.
                DISPLAY ' V-EMPID ' V-EMPID.
                DISPLAY ' V-DESIGNATION ' V-DESIGNATION.
                DISPLAY ' V-RATING ' V-RATING.
                DISPLAY ' V-SALARY ' V-SALARY.
                DISPLAY ' V-DOJ   ' V-DOJ.
                DISPLAY ' V-DAYS-WORKED ' V-DAYS-WORKED(1, 5).
                WRITE VSAMOFF-DETAILS FROM OEMP-REC
                AFTER ADVANCING 2 LINES.
