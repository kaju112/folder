# KDM to COBOL Source Reconstruction

## Overview

This project reconstructs COBOL source code from a KDM Graph export (CSV/XLSX) generated from Neo4j.

The KDM graph contains:

- Statement metadata
- Source line numbers
- Source positions
- Paragraph information
- Statement kinds
- File operation metadata

Using this information, the script regenerates executable COBOL statements and attempts to reconstruct the original program structure.

---

# Architecture

```text
+------------------+
| Neo4j Export     |
| CSV / XLSX       |
+---------+--------+
          |
          v
+------------------+
| read_table()     |
+---------+--------+
          |
          v
+----------------------+
| normalize_columns()  |
+---------+------------+
          |
          v
+----------------------+
| reconstruct()        |
| Main Engine          |
+---------+------------+
          |
          +-------------------+
          |                   |
          |                   |
          v                   v
+----------------+    +-------------------+
| Statement      |    | Paragraph         |
| Reconstruction |    | Recovery          |
+-------+--------+    +---------+---------+
        |                       |
        +-----------+-----------+
                    |
                    v
        +---------------------+
        | ArrayCOB Buffer     |
        +----------+----------+
                   |
                   v
        +---------------------+
        | write_cobol()       |
        +----------+----------+
                   |
                   v
        +---------------------+
        | COBOL Source (.cob) |
        +---------------------+
```

---

# Processing Flow

```mermaid
flowchart TD

A[Read CSV/XLSX] --> B[Normalize Column Names]

B --> C[Convert Line Numbers]
C --> D[Sort Rows]

D --> E[Allocate ArrayCOB]

E --> F[Process Statements]

F --> G1[Single Line Statements]
F --> G2[IF Blocks]
F --> G3[OPEN]
F --> G4[STOP RUN]
F --> G5[AT END]
F --> G6[NOT AT END]
F --> G7[MOVE Split]
F --> G8[WRITE Split]

G1 --> H
G2 --> H
G3 --> H
G4 --> H
G5 --> H
G6 --> H
G7 --> H
G8 --> H

H[READNEXT Recovery]

H --> I[Paragraph Recovery]

I --> J[Generate COBOL File]

J --> K[Output .COB]
```

---

# Sequence Diagram

```mermaid
sequenceDiagram

participant User
participant Script
participant Reader
participant Normalizer
participant Reconstructor
participant Writer

User->>Script: Run command

Script->>Reader: Read CSV/XLSX

Reader-->>Script: DataFrame

Script->>Normalizer: Normalize headers

Normalizer-->>Script: Standardized DataFrame

Script->>Reconstructor: Reconstruct COBOL

loop For every row

Reconstructor->>Reconstructor: Process Statement

alt IF
Reconstructor->>Reconstructor: Generate END-IF

else OPEN
Reconstructor->>Reconstructor: Build OPEN statement

else READNEXT
Reconstructor->>Reconstructor: Process later

else MOVE/WRITE multiline
Reconstructor->>Reconstructor: Split statement

end

end

Reconstructor->>Reconstructor: Recover READNEXT

Reconstructor->>Reconstructor: Recover Paragraphs

Reconstructor-->>Script: ArrayCOB

Script->>Writer: Write COB file

Writer-->>User: regenerated.cob
```

---

# Program Workflow

The reconstruction process consists of six stages.

## Stage 1

Read input file.

Supported formats:

- CSV
- XLSX
- XLSM
- XLS

Responsible Function:

```python
read_table()
```

---

## Stage 2

Normalize column names.

Different Neo4j exports may use:

```text
StartLine
Start line
startLine
```

All are mapped to:

```python
start_line
```

Responsible Function:

```python
normalize_columns()
```

---

## Stage 3

Prepare source coordinates.

Convert:

```text
StartLine = 112
EndLine = 112
```

into:

```python
start_idx = 111
end_idx = 111
```

This allows direct insertion into ArrayCOB.

Responsible Function:

```python
normalize_columns()
```

---

## Stage 4

Reconstruct statements.

Responsible Function:

```python
reconstruct()
```

This is the main engine of the project.

---

# Statement Handling Logic

## Single Line Statements

Example

```cobol
DISPLAY WS-EMP-OFF
```

Condition

```python
StartLine == EndLine
```

Action

```python
ArrayCOB[line] = stmt_text
```

---

## IF Blocks

Example

```cobol
IF WS-SIGNCHECK = '-'
```

KDM only contains:

```cobol
IF condition
```

Script generates:

```cobol
END-IF.
```

at EndLine.

---

## ELSE Blocks

KDM:

```text
Kind = ELSE
```

Output:

```cobol
ELSE
```

---

## OPEN Statements

KDM stores:

```text
Kind = OPEN
File Name
Operating Mode
```

Generated:

```cobol
OPEN INPUT OEMP
```

or

```cobol
OPEN EXTEND VSAMOFF
```

---

## STOP_RUN

KDM:

```text
Kind = STOP_RUN
```

Generated:

```cobol
STOP RUN.
```

---

## AT_END

Input

```cobol
MOVE 'Y' TO WS-EOF
```

Generated

```cobol
AT END MOVE 'Y' TO WS-EOF
```

---

## NOT_AT_END

Input

```cobol
PERFORM A100-MOVE-DATA
```

Generated

```cobol
NOT AT END PERFORM A100-MOVE-DATA
```

---

## READNEXT

Example

```cobol
READ OEMP NEXT RECORD
AT END ...
NOT AT END ...
END-READ.
```

KDM stores the whole construct as one node.

The script:

1. Finds child statements
2. Extracts READ header
3. Reconstructs END-READ

---

## Multi-Line MOVE

Input node:

```cobol
MOVE FUNCTION LENGTH V-DESIGNATION TO WS-STRING-LENGTH.
```

KDM:

```text
StartLine = 162
EndLine = 163
```

Generated:

```cobol
MOVE FUNCTION LENGTH V-DESIGNATION
TO WS-STRING-LENGTH.
```

---

## Multi-Line WRITE

Input node:

```cobol
WRITE VSAMOFF-DETAILS FROM OEMP-REC AFTER ADVANCING 2 LINES.
```

Generated:

```cobol
WRITE VSAMOFF-DETAILS FROM OEMP-REC
AFTER ADVANCING 2 LINES.
```

---

# ArrayCOB

ArrayCOB acts as a temporary source file buffer.

Example:

```python
ArrayCOB[111]
```

represents:

```cobol
source line 112
```

Before writing output:

```python
[
 "",
 "",
 "A100-MOVE-DATA.",
 "OPEN INPUT OEMP",
 ...
]
```

After joining:

```cobol
A100-MOVE-DATA.
OPEN INPUT OEMP
...
```

---

# Function Summary

## read_table()

### Purpose

Loads input data.

### Input

```python
Path
```

### Output

```python
DataFrame
```

---

## normalize_columns()

### Purpose

Standardize all column names.

### Output

```python
Normalized DataFrame
```

Adds:

```python
start_idx
end_idx
```

---

## indent()

### Purpose

Generate indentation.

Example

```python
StartPos = 17
```

Output

```python
16 spaces
```

---

## put_line()

### Purpose

Safely write line into ArrayCOB.

Prevents accidental overwrites.

---

## split_two_line_statement()

### Purpose

Split multiline MOVE or WRITE.

Example

```cobol
MOVE A TO B
```

across two source lines.

---

## infer_paragraph_lines()

### Purpose

Determine where paragraph declarations belong.

Generates:

```cobol
A100-MOVE-DATA.
A110-READ-PARA.
```

---

## reconstruct()

### Purpose

Main reconstruction engine.

Responsibilities:

- Process statements
- Process IF
- Process ELSE
- Process OPEN
- Process READNEXT
- Process AT END
- Process NOT AT END
- Recover paragraphs

---

## write_cobol()

### Purpose

Generate final .cob file.

---

## main()

### Purpose

Entry point.

Workflow:

```text
Read
 ↓
Normalize
 ↓
Reconstruct
 ↓
Write COBOL
```

---

# Complexity

## Time Complexity

Sorting:

```text
O(N log N)
```

Reconstruction:

```text
O(N)
```

Paragraph Recovery:

```text
O(N)
```

Overall:

```text
O(N log N)
```

---

# Limitations

The KDM graph does not contain the complete source file.

The script cannot reconstruct:

- Identification Division
- Environment Division
- Data Division
- Working Storage
- File Section
- Copybooks
- Comments
- Exact blank lines

Therefore:

```text
Executable Logic        = High Accuracy
Full Source Recreation  = Partial Accuracy
```

---

# Future Improvements

## Phase 1

Recover divisions using KDM metadata.

## Phase 2

Recover Data Division variables.

## Phase 3

Recover FILE SECTION structures.

## Phase 4

Generate complete compilable COBOL program.

## Phase 5

Create bidirectional transformation:

```text
COBOL
  ↔
KDM Graph
```

---

# Example Execution

```bash
python kdm_to_cobol.py \
    Final_graphjson_neo4j.xlsx \
    -o regenerated.cob \
    -v
```

Output

```text
COBOL reconstruction written to:
regenerated.cob

Represented lines: 61 of 172
```