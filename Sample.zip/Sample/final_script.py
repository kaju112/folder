#!/usr/bin/env python3
"""Regenerate the available COBOL source lines from a KDM/Neo4j CSV or XLSX export."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

import pandas as pd

COLUMN_ALIASES = {
    "type": ["Type", "type", "node.type"],
    "name": ["Name", "name", "node.name"],
    "kind": ["Kind", "kind", "node.kind"],
    "seq_no": ["seqNo", "SeqNo", "seq_no", "sequence"],
    "start_pos": ["StartPos", "Start Pos", "startPos", "sPos", "start_pos"],
    "end_pos": ["EndPos", "End Pos", "endPos", "ePos", "end_pos"],
    "start_line": ["StartLine", "Start Line", "Start line", "startLine", "start_line"],
    "end_line": ["EndLine", "End Line", "End line", "endLine", "end_line"],
    "node_path": ["nodePath", "node.nodePath", "NodePath", "node_path"],
    "stmt_text": ["StmtText", "Stmnt Text", "Statement Text", "stmtText", "stmt_text"],
    "file_name": ["filename", "fileName", "FileName", "file_name"],
    "operating_mode": ["operatingmode", "operatingMode", "OperatingMode", "operating_mode"],
    "node_id": ["id", "node.id", "NodeId", "node_id"],
}


def _clean_header(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).strip().lower())


def _is_missing(value: Any) -> bool:
    if value is None or pd.isna(value):
        return True
    return str(value).strip().lower() in {"", "null", "none", "nan", "<na>"}


def _text(value: Any) -> str:
    return "" if _is_missing(value) else str(value).strip()


def _integer(value: Any, default: int | None = None) -> int | None:
    if _is_missing(value):
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def read_table(path: Path, sheet: str | int = 0) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, dtype=object, keep_default_na=True)
    if suffix in {".xlsx", ".xlsm"}:
        return pd.read_excel(path, sheet_name=sheet, dtype=object, engine="openpyxl")
    if suffix == ".xls":
        return pd.read_excel(path, sheet_name=sheet, dtype=object, engine="xlrd")
    raise ValueError(f"Unsupported input type: {suffix}. Use CSV, XLSX, XLSM, or XLS.")

def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    normalized_lookup = {_clean_header(col): col for col in df.columns}
    rename_map: dict[str, str] = {}
    missing_required: list[str] = []

    for canonical, aliases in COLUMN_ALIASES.items():
        source = next(
            (normalized_lookup[_clean_header(a)] for a in aliases
             if _clean_header(a) in normalized_lookup),
            None,
        )
        if source is not None:
            rename_map[source] = canonical
        elif canonical in {"start_line", "end_line", "kind", "stmt_text"}:
            missing_required.append(canonical)

    if missing_required:
        raise ValueError(
            "Missing required columns: " + ", ".join(missing_required) +
            ". Available columns: " + ", ".join(map(str, df.columns))
        )

    result = df.rename(columns=rename_map).copy()
    for optional in COLUMN_ALIASES:
        if optional not in result.columns:
            result[optional] = pd.NA

    for col in ["start_line", "end_line", "start_pos", "end_pos", "seq_no"\]:
        result[col] = pd.to_numeric(result[col], errors="coerce").astype("Int64")

    result["kind"] = result["kind"].map(_text).str.upper()
    result["type"] = result["type"].map(_text)
    result["name"] = result["name"].map(_text)
    result["node_path"] = result["node_path"].map(_text)
    result["stmt_text"] = result["stmt_text"].map(_text)
    result["file_name"] = result["file_name"].map(_text)
    result["operating_mode"] = result["operating_mode"].map(_text).str.upper()

    # Preserve original line numbers, then apply the documented -1 decrement
    # and convert to zero-based list indexes.
    result["original_start_line"] = result["start_line"]
    result["original_end_line"] = result["end_line"]
    result["start_line"] = result["start_line"] - 1
    result["end_line"] = result["end_line"] - 1
    result["start_idx"] = result["start_line"] - 1
    result["end_idx"] = result["end_line"] - 1

    checks = {
        "StartLine decrement": result["start_line"] == result["original_start_line"] - 1,
        "EndLine decrement": result["end_line"] == result["original_end_line"] - 1,
        "StartLine-to-list-index": result["start_idx"] == result["start_line"] - 1,
        "EndLine-to-list-index": result["end_idx"] == result["end_line"] - 1,
    }
    for label, check in checks.items():
        if not bool(check.fillna(True).all()):
            raise ValueError(f"{label} validation failed.")

    return result.sort_values(
        ["start_line", "node_path", "seq_no"],
        kind="stable",
        na_position="last",
    ).reset_index(drop=True)
    def indent(start_pos: Any) -> str:
    """StartPos - 1 spaces; missing positions safely become zero."""
    return " " * max((_integer(start_pos, 1) or 1) - 1, 0)


def put_line(lines: list[str | None], index: int | None, text: str,
             *, overwrite: bool = False) -> None:
    if index is None or index < 0 or index >= len(lines) or not text:
        return
    if lines[index] is None or overwrite:
        lines[index] = text.rstrip()


def split_two_line_statement(stmt: str, start_pos: int, end_pos: int) -> tuple[str, str\]:
    """Apply the MOVE/WRITE two-line rule with defensive bounds."""
    length = max(end_pos - start_pos, 0)
    if length <= 0 or length >= len(stmt):
        matches = list(re.finditer(r"\s+", stmt))
        if not matches:
            return stmt, ""
        cut = min(matches, key=lambda m: abs(m.start() - len(stmt) // 2)).end()
        return stmt[:cut].rstrip(), stmt[cut:].lstrip()
    return stmt[:-length].rstrip(), stmt[-length:].lstrip()


def get_paragraph_positions(df: pd.DataFrame) -> list[tuple[int, str]]::
    """Recover paragraph order from nodePath and derive insertion positions."""
    paragraphs = df[df["kind"].str.lower() == "cobol_paragraph"].copy()
    if paragraphs.empty:
        return []

    paragraphs["para_idx"] = (
        paragraphs["node_path"].str.extract(r"paraList\.(\d+)").astype(int)
    )
    paragraphs = paragraphs.sort_values("para_idx", kind="stable")

    stmt_kinds = ["OPEN", "STOP_RUN", "ELSE", "AT_END", "NOT_AT_END", "READNEXT"]
    stmt_lines = sorted({
        int(v)
        for v in df.loc[
            ((df["stmt_text"] != "") | df["kind"].isin(stmt_kinds))
            & df["start_line"].notna(),
            "start_line",
        ].tolist()
        if int(v) > 1
    })
    if not stmt_lines:
        return []

    placements: list[tuple[int, str]] = []
    paragraph_names = paragraphs["name"].tolist()

    if paragraph_names:
        placements.append((stmt_lines[0] - 2, f"{paragraph_names[0]}."))

    readnext_row = df[df["kind"] == "READNEXT"]
    if len(paragraph_names) >= 2 and not readnext_row.empty:
        placements.append(
            (int(readnext_row.iloc[0]["start_line"]) - 2, f"{paragraph_names[1]}.")
        )

    after_read = df[
        df["start_line"] > (
            int(readnext_row.iloc[0]["end_line"]) if not readnext_row.empty else 0
        )
    ]
    if len(paragraph_names) >= 3 and not after_read.empty:
        placements.append(
            (int(after_read["start_line"].min()) - 2, f"{paragraph_names[2]}.")
        )

    return placements


def add_periods(lines: list[str | None], df: pd.DataFrame) -> list[str\]:
    """Period rules:
    1. Multiline block (start_idx != end_idx): period ONLY on the last line.
    2. No period after a PERFORM statement.
    3. Otherwise: add a period after every non-empty line.
    """
    lines = ["" if line is None else line for line in lines]
    paragraph_re = re.compile(r"^[A-Z0-9-]+\.$")

    block_non_terminal_indexes: set[int] = set()
    block_last_indexes: set[int] = set()

    for _, row in df.iterrows():
        start_idx = _integer(row.get("start_idx"))
        end_idx = _integer(row.get("end_idx"), start_idx)
        if start_idx is None or end_idx is None or start_idx < 0 or end_idx < 0:
            continue
        if start_idx != end_idx:
            block_last_indexes.add(end_idx)
            block_non_terminal_indexes.update(range(start_idx, end_idx))

    for idx, line in enumerate(lines):
        if not line:
            continue
        stripped = line.strip()
        if paragraph_re.match(stripped) or stripped.endswith("."):
            continue
        if idx in block_non_terminal_indexes:
            continue
        if idx in block_last_indexes:
            lines[idx] = line.rstrip() + "."
            continue
        if stripped.upper().startswith("PERFORM "):
            continue
        lines[idx] = line.rstrip() + "."

    return lines

FILE_DESCRIPTION_ALIASES = {
    "node_id": ["node_id", "node.id", "id"],
    "kind": ["kind"],
    "start_line": ["start_line", "StartLine", "Start line", "Start Line"],
    "end_line": ["end_line", "EndLine", "End line", "End Line"],
    "start_pos": ["start_pos", "StartPos", "sPos", "Start Pos"],
    "end_pos": ["end_pos", "EndPos", "ePos", "End Pos"],
    "level_no": ["level_no", "levelNo"],
    "var_name": ["var_name", "varName"],
    "pic_string": ["pic_string", "picString"],
    "usage": ["usage"],
    "signed_flag": ["signed_flag", "signedFlag"],
    "sign_position": ["sign_position", "signPosition"],
    "array_flag": ["array_flag", "arrayFlag"],
    "occurs_from": ["occurs_from", "occursFrom"],
    "occurs_to": ["occurs_to", "occursTo"],
    "indexed_by": ["indexed_by", "indexedBy"],
    "depending_on": ["depending_on", "dependingOn"],
    "redefine_flag": ["redefine_flag", "redefineFlag"],
    "redefine_var": ["redefine_var", "redefineVar"],
    "rename_flag": ["rename_flag", "renameFlag"],
    "rename_var": ["rename_var", "renameVar"],
    "initial_value": ["initial_value", "initialValue"],
    "node_path": ["node_path", "nodePath", "node.nodePath"],
    "DDName": ["DDName"],
    "organization": ["organization"],
    "access": ["access"],
    "Keyinformation": ["Keyinformation"],
    "FileStatusVariable": ["FileStatusVariable"],
}


def normalize_file_description(df: pd.DataFrame) -> pd.DataFrame:
    lookup = {_clean_header(c): c for c in df.columns}
    rename: dict[str, str] = {}
    for key, aliases in FILE_DESCRIPTION_ALIASES.items():
        src = next((lookup[_clean_header(a)] for a in aliases
                    if _clean_header(a) in lookup), None)
        if src is not None:
            rename[src] = key

    out = df.rename(columns=rename).copy()
    for col in FILE_DESCRIPTION_ALIASES:
        if col not in out:
            out[col] = pd.NA

    # FILE-CONTROL metadata
    out["DDName"] = out["DDName"].map(_text)
    out["organization"] = out["organization"].map(_text).str.upper()
    out["access"] = out["access"].map(_text).str.upper()
    out["Keyinformation"] = out["Keyinformation"].map(_text)
    out["FileStatusVariable"] = out["FileStatusVariable"].map(_text)

    for col in ["start_line", "end_line", "start_pos", "end_pos", "level_no"\]:
        out[col] = pd.to_numeric(out[col], errors="coerce").astype("Int64")

    out["original_start_line"] = out["start_line"]
    out["original_end_line"] = out["end_line"]
    out["start_line"] = out["start_line"] - 1
    out["end_line"] = out["end_line"] - 1
    out["start_idx"] = out["start_line"] - 1
    out["end_idx"] = out["end_line"] - 1

    return out.sort_values(
        ["start_line", "node_path"], kind="stable", na_position="last"
    ).reset_index(drop=True)
def _fd_flag(value: Any) -> bool:
    return _text(value).upper() in {"Y", "YES", "TRUE", "1"}


def _fd_level(value: Any) -> str:
    n = _integer(value)
    return "" if n is None else f"{n:02d}"


def _fd_tail(value: Any) -> str:
    text = _text(value)
    return text.rsplit("&&&", 1)[-1] if text else ""


def _fd_list_index(path: Any, name: str) -> int | None:
    match = re.search(rf"{re.escape(name)}\.(\d+)", _text(path), re.I)
    return int(match.group(1)) if match else None


def build_file_data_clause(row) -> str:
    level = _fd_level(row.get("level_no"))
    name = _text(row.get("var_name"))
    if not level or not name:
        return ""

    parts = [level, name]

    redefine_var = _text(row.get("redefine_var"))
    if _fd_flag(row.get("redefine_flag")) and redefine_var:
        parts += ["REDEFINES", redefine_var]

    rename_var = _text(row.get("rename_var"))
    if _fd_flag(row.get("rename_flag")) and rename_var:
        parts += ["RENAMES", rename_var]

    pic = _text(row.get("pic_string"))
    if pic:
        parts += ["PIC", pic]

    usage = _text(row.get("usage"))
    if usage:
        parts.append(usage.upper())

    if _fd_flag(row.get("signed_flag")):
        parts += ["SIGN IS", (_text(row.get("sign_position")) or "TRAILING").upper()]

    # OCCURS: zero / blank / "[]" are treated as not present.
    occurs_from = _integer(row.get("occurs_from"))
    occurs_to = _integer(row.get("occurs_to"))
    if occurs_from is not None and occurs_from <= 0:
        occurs_from = None
    if occurs_to is not None and occurs_to <= 0:
        occurs_to = None

    depending_on = _text(row.get("depending_on")) or None
    indexed_by = _text(row.get("indexed_by")) or None
    if depending_on == "[]":
        depending_on = None
    if indexed_by == "[]":
        indexed_by = None

    if occurs_from and occurs_to:
        parts.append(f"OCCURS {occurs_from} TO {occurs_to} TIMES")
    elif occurs_to:
        parts.append(f"OCCURS {occurs_to} TIMES")
    elif occurs_from:
        parts.append(f"OCCURS {occurs_from} TIMES")

    if depending_on:
        parts.append(f"DEPENDING ON {depending_on}")
    if indexed_by:
        parts.append(f"INDEXED BY {indexed_by}")

    value = _text(row.get("initial_value"))
    if value:
        parts += ["VALUE", value]

    return " ".join(parts) + "."


def build_select_entries(file_df: pd.DataFrame) -> list[str\]:
    records: dict[int, str] = {}
    ddnames: dict[int, str] = {}
    organizations: dict[int, str] = {}
    accesses: dict[int, str] = {}
    keyinfos: dict[int, str] = {}
    file_statuses: dict[int, str] = {}

    for _, row in file_df.iterrows():
        idx = _fd_list_index(row.get("node_path"), "FDLIST")
        if idx is None:
            continue
        kind = _text(row.get("kind")).lower()
        if kind == "recordfile":
            records[idx] = _fd_tail(row.get("node_id"))
            organizations[idx] = _text(row.get("organization"))
            accesses[idx] = _text(row.get("access"))
            keyinfos[idx] = _text(row.get("Keyinformation"))
            file_statuses[idx] = _text(row.get("FileStatusVariable"))
        elif kind == "program_ddname":
            ddnames[idx] = _fd_tail(row.get("node_id"))

    result: list[str] = []
    for idx in sorted(records):
        select_lines = [f"SELECT {records[idx]}"]

        ddname = ddnames.get(idx, "")
        if ddname:
            select_lines.append(f"       ASSIGN TO {ddname}")

        org = organizations.get(idx, "")
        if org:
            org = (org.replace("RECORD INDEXED", "INDEXED")
                      .replace("RECORD SEQUENTIAL", "SEQUENTIAL"))
            select_lines.append(f"       ORGANIZATION IS {org}")

        access = accesses.get(idx, "")
        if access:
            select_lines.append(f"       ACCESS MODE IS {access}")

        keyinfo = keyinfos.get(idx, "")
        if keyinfo:
            select_lines.append(f"       RECORD KEY IS {keyinfo}")

        status = file_statuses.get(idx, "")
        if status:
            select_lines.append(f"       FILE STATUS IS {status}")

        select_lines[-1] += "."
        result.append("\n".join(select_lines))

    return result

def overlay_file_description(lines: list[str | None], file_df: pd.DataFrame,
                             warnings: list[str]) -> list[str | None\]:
    rows = file_df[file_df["var_name"].map(_text) != ""].copy()
    if rows.empty:
        warnings.append("No file-description var_name rows found.")
        return lines

    max_line = int(rows["start_line"].dropna().max())
    if len(lines) < max_line:
        lines.extend([""] * (max_line - len(lines)))

    # RecordFile names, keyed by FDLIST index.
    roots: dict[int, str] = {}
    for _, r in file_df.iterrows():
        if _text(r.get("kind")).lower() == "recordfile":
            fd_idx = _fd_list_index(r.get("node_path"), "FDLIST")
            if fd_idx is not None:
                roots[fd_idx] = _fd_tail(r.get("node_id"))

    first_fd_line: int | None = None

    for _, r in rows.iterrows():
        idx = _integer(r.get("start_idx"))
        clause = build_file_data_clause(r)
        if idx is None or idx < 0 or not clause:
            continue
        if idx >= len(lines):
            lines.extend([""] * (idx - len(lines) + 1))

        lines[idx] = indent(r.get("start_pos")) + clause

        # Insert FD immediately above each level-01 item.
        if _fd_level(r.get("level_no")) == "01":
            root_idx = _fd_list_index(r.get("node_path"), "symbolArray")
            fd_name = roots.get(root_idx)
            if fd_name and idx > 0:
                fd_line_idx = idx - 1
                if lines[fd_line_idx] in (None, ""):
                    lines[fd_line_idx] = f"      FD {fd_name}."
                    if first_fd_line is None or fd_line_idx < first_fd_line:
                        first_fd_line = fd_line_idx
                else:
                    warnings.append(
                        f"FD {fd_name} could not be placed at physical line "
                        f"{fd_line_idx + 1}."
                    )

    # Place FILE-CONTROL in the reserved space before the first FD.
    if first_fd_line is not None:
        pre = ["ENVIRONMENT DIVISION.", "INPUT-OUTPUT SECTION.", "FILE-CONTROL."]
        for entry in build_select_entries(file_df):
            pre.extend(entry.splitlines())
        pre.extend(["DATA DIVISION.", "FILE SECTION."])

        if len(pre) > first_fd_line:
            warnings.append(
                f"Need {len(pre)} lines before first FD but only "
                f"{first_fd_line} reserved."
            )
        else:
            for idx, text in enumerate(pre):
                if lines[idx] not in (None, ""):
                    warnings.append(
                        f"Cannot place FILE-CONTROL line '{text}' at physical "
                        f"line {idx + 1}; line already occupied."
                    )
                    continue
                lines[idx] = text

    return lines
def add_periods(lines: list[str | None], df: pd.DataFrame) -> list[str\]:
    """Period rules:
    1. Multiline block (start_idx != end_idx): period ONLY on the last line.
    2. No period after a PERFORM statement.
    3. Otherwise: add a period after every non-empty line.
    """
    lines = ["" if line is None else line for line in lines]
    paragraph_re = re.compile(r"^[A-Z0-9-]+\.$")

    block_non_terminal_indexes: set[int] = set()
    block_last_indexes: set[int] = set()

    for _, row in df.iterrows():
        start_idx = _integer(row.get("start_idx"))
        end_idx = _integer(row.get("end_idx"), start_idx)
        if start_idx is None or end_idx is None or start_idx < 0 or end_idx < 0:
            continue
        if start_idx != end_idx:
            block_last_indexes.add(end_idx)
            block_non_terminal_indexes.update(range(start_idx, end_idx))

    for idx, line in enumerate(lines):
        if not line:
            continue
        stripped = line.strip()
        if paragraph_re.match(stripped) or stripped.endswith("."):
            continue
        if idx in block_non_terminal_indexes:
            continue
        if idx in block_last_indexes:
            lines[idx] = line.rstrip() + "."
            continue