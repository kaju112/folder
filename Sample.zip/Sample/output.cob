FILE-CONTROL.

SELECT OEMP ASSIGN TO IN1.
SELECT VSAMOFF ASSIGN TO OUT1.






FILE SECTION.








01 OEMP-REC.
      05 O-EMPID PIC X(5).
      05 O-DESIGNATION PIC X(10).
      05 O-RATING PIC X(03).

      05 O-SALARY PIC 9(02)V9(02).
      05 O-DOJ.
         08 O-DOJ-YEAR PIC X(04).
         08 O-DOJ-MONTH PIC X(02).
         08 0-DOJ-DAY PIC X(02).
      05 O-EMP-ATTENDANCE-YEAR OCCURS 0 TO 3 TIMES.
             10 O-EMP-ATTENDANCE-MONTH OCCURS 0 TO 12 TIMES.
                 15 O-DAYS-WORKED PIC 9(02).
      05 FILLER PIC X(50).

01 VSAMOFF-DETAILS.
      05 V-EMPID PIC X(5).
      05 V-DESIGNATION PIC X(10).
      05 V-RATING PIC S9(02) SIGN IS LEADING SEPARATE.

      05 V-SALARY PIC 99V99 USAGE COMP-3.
      05 V-DOJ.
         08 V-DOJ-YEAR PIC X(04).
         08 V-DOJ-MONTH PIC X(02).
         08 V-DOJ-DAY PIC X(02).
      05 V-EMP-ATTENDANCE-YEAR OCCURS 0 TO 3 TIMES.
             10 V-EMP-ATTENDANCE-MONTH OCCURS 0 TO 12 TIMES.
                 15 V-DAYS-WORKED PIC 9(02).
      05 FILLER PIC X(51).
















































