IDENTIFICATION DIVISION.
PROGRAM-ID.
ENVIRONMENT DIVISION.
INPUT-OUTPUT SECTION.
FILE-CONTROL.
SELECT OEMP ASSIGN TO IN1.
ORGANIZATION IS SEQUENTIAL.
ACCESS MODE IS SEQUENTIAL.
FILE STATUS IS WS-FS.
SELECT VSAMOFF ASSIGN TO OUT1.
ORGANIZATION IS INDEXED.
ACCESS MODE IS SEQUENTIAL.
RECORD KEY IS V-EMPID.
FILE STATUS IS WS-FS1.
DATA DIVISION.
FILE SECTION.

      FD OEMP.
      01 OEMP-REC.
            05 O-EMPID PIC X(5).
            05 O-DESIGNATION PIC X(10).
            05 O-RATING PIC X(03).

            05 O-SALARY PIC 9(02)V9(02).
            05 O-DOJ.
               08 O-DOJ-YEAR PIC X(04).
               08 O-DOJ-MONTH PIC X(02).
               08 0-DOJ-DAY PIC X(02).
            05 O-EMP-ATTENDANCE-YEAR OCCURS 3 TIMES.
                   10 O-EMP-ATTENDANCE-MONTH OCCURS 12 TIMES.
                       15 O-DAYS-WORKED PIC 9(02).
            05 FILLER PIC X(50).
      FD VSAMOFF.
      01 VSAMOFF-DETAILS.
            05 V-EMPID PIC X(5).
            05 V-DESIGNATION PIC X(10).
            05 V-RATING PIC S9(02) SIGN IS LEADING SEPARATE.

            05 V-SALARY PIC 99V99 COMP-3.
            05 V-DOJ.
               08 V-DOJ-YEAR PIC X(04).
               08 V-DOJ-MONTH PIC X(02).
               08 V-DOJ-DAY PIC X(02).
            05 V-EMP-ATTENDANCE-YEAR OCCURS 3 TIMES.
                   10 V-EMP-ATTENDANCE-MONTH OCCURS 12 TIMES.
                       15 V-DAYS-WORKED PIC 9(02).
            05 FILLER PIC X(51).





























































PROCEDURE DIVISION.
SEC-ROOT-PARA-0.
           OPEN INPUT OEMP.
           OPEN EXTEND VSAMOFF.
           DISPLAY ' FILE STATUS FOR PS ' WS-FS.
           DISPLAY ' FILE STATUS FOR VSAM ' WS-FS1.
           PERFORM A110-READ-PARA UNTIL WS-EOF = 'Y'
           CLOSE OEMP.
           CLOSE VSAMOFF.
           STOP RUN.
A110-READ-PARA.
           READ OEMP NEXT RECORD
           AT END MOVE 'Y' TO WS-EOF
           DISPLAY ' WS-EOF ' WS-EOF
           NOT AT END PERFORM A100-MOVE-DATA
           DISPLAY ' WS-EOF ' WS-EOF
           END-READ.
A100-MOVE-DATA.
                DISPLAY WS-EMP-OFF.
                DISPLAY ' WS-EMPID ' WS-EMPID.
                DISPLAY ' WS-DESIGNATION' WS-DESIGNATION.
                DISPLAY ' WS-RATING ' WS-RATING.
                DISPLAY ' WS-SALARY ' WS-SALARY.
                DISPLAY ' WS-DOJ  ' WS-DOJ.
                MOVE O-EMPID TO V-EMPID.
                DISPLAY 'V-EMPID ' V-EMPID.
                MOVE O-DESIGNATION TO V-DESIGNATION.
                DISPLAY 'V-DESIGNATION ' V-DESIGNATION.
                DISPLAY ' WS-RATING ' O-RATING.
                MOVE O-RATING(1:1) TO WS-SIGNCHECK.
                DISPLAY ' O-RATING(1:1) ' O-RATING(1:1).
                DISPLAY ' WS-SIGNCHECK   ' WS-SIGNCHECK.
                MOVE O-RATING TO WS-TEMP.
                DISPLAY ' WS-TEMP ' WS-TEMP.
                IF WS-SIGNCHECK = '-'
                   COMPUTE V-RATING = -1 * WS-TEMP
                ELSE
                   MOVE WS-TEMP TO V-RATING
                END-IF.
                DISPLAY 'V-RATING      ' V-RATING.
                COMPUTE O-SALARY = O-SALARY + WS-ALLOWANCES.
                IF O-SALARY EQUAL ZEROES
                   DISPLAY 'SALARY SHOULD HAVE VALUE'
                ELSE
                   MOVE O-SALARY TO V-SALARY
                   DISPLAY 'V-SALARY      ' V-SALARY
                END-IF.
                MOVE O-DOJ   TO V-DOJ.
                MOVE 21 TO V-DAYS-WORKED(1, 5).
                IF V-DESIGNATION NOT NUMERIC
                   DISPLAY 'DESIGNATION IS NOT NUMERIC'
                END-IF.
                MOVE FUNCTION LENGTH V-DESIGNATION
                TO WS-STRING-LENGTH.
                DISPLAY 'V-DOJ         ' V-DOJ.
                DISPLAY ' V-EMPID ' V-EMPID.
                DISPLAY ' V-DESIGNATION ' V-DESIGNATION.
                DISPLAY ' V-RATING ' V-RATING.
                DISPLAY ' V-SALARY ' V-SALARY.
                DISPLAY ' V-DOJ   ' V-DOJ.
                DISPLAY ' V-DAYS-WORKED ' V-DAYS-WORKED(1, 5).
                WRITE VSAMOFF-DETAILS FROM OEMP-REC
                AFTER ADVANCING 2 LINES.
