# KDM → COBOL Reconstruction

`updated_2_kdm_2_cobol.py` regenerates approximate COBOL source from a
KDM/Neo4j graph export (CSV/XLSX). The full narrative pseudocode lives in
`KDM_2_COBOL_Pseudocode_Updated.docx`; this file explains what the code
does and why.

## Brief explanation

The script reads a table of KDM graph nodes (one row per statement,
paragraph, or variable, each carrying a `StartLine`/`EndLine` pair from the
original COBOL source). It re-derives the physical line each node belongs
to, writes the node's reconstructed COBOL text into an in-memory array of
output lines (`ArrayCOB`), fills in paragraph headers and a
`PROCEDURE DIVISION.` line, optionally overlays a `FILE-CONTROL`/`FD` block
from a second "file description" export, appends periods where COBOL
requires them, and writes the result to a `.cob` file. Because the KDM
export mainly covers executable statements, any source line the export
doesn't represent is left blank rather than guessed.

```bash
python3 updated_2_kdm_2_cobol.py Final_graphjson_neo4j.xlsx \
    --file-description filedescription_2.xlsx \
    -o VSAMPRGM_RECONSTRUCTED.cob -v
```

## Detailed explanation

### 1. Input loading and column normalization
`read_table()` picks a pandas reader based on file extension (CSV,
XLSX/XLSM via openpyxl, XLS via xlrd). Real-world exports spell columns
inconsistently (`StartLine` vs `startLine` vs `start_line`), so
`normalize_columns()` matches every column against `COLUMN_ALIASES`
(case/punctuation-insensitive) and renames it to a canonical name. It
raises immediately if a truly required column (`start_line`, `end_line`,
`kind`, `stmt_text`) is missing — the rest of the script assumes these
exist. Numeric columns are coerced to nullable `Int64` so missing values
don't crash arithmetic later.

**Line-number remap.** The export's `StartLine`/`EndLine` are 1 higher than
the physical COBOL line they describe, and Python lists are 0-based on top
of that. So each value is decremented twice: once to get the true physical
line (`start_line = original - 1`), and once more to get a 0-based list
index (`start_idx = start_line - 1`). Both decrements are re-validated
against the original values immediately after, so a bad assumption fails
loudly instead of silently misplacing every line by one.

### 2. Statement placement (`reconstruct()`, pass 1)
For every row, the code decides how to write it into `ArrayCOB` based on
`kind` and whether its line number is shared with another row
("repeated"):

- **Single-line statement** (`start_line == end_line`): write `StmtText`
  indented by `StartPos - 1` spaces.
- **`IF`**: write the condition at `start_idx`, and `END-IF` at `end_idx`
  (multiline block).
- **`MOVE`/`WRITE` spanning exactly two lines**: split `StmtText` using
  `EndPos - StartPos` characters from the end (falling back to the nearest
  whitespace to the midpoint if that split is invalid), writing one half to
  each line.
- **Rows that share a line with siblings** (`OPEN`, `STOP_RUN`, `ELSE`,
  `AT_END`/`NOT_AT_END`) are reconstructed from their combined fields — e.g.
  `OPEN` needs both `filename` and `operatingmode` from two different sibling
  rows, and `AT_END`/`NOT_AT_END` borrows the sibling's `StmtText` to build
  `AT END <condition>`.
- `READNEXT` and other genuinely multiline kinds are deferred to pass 2.

### 3. READNEXT header recovery (pass 2)
A `READNEXT` (`READ ... NEXT`) statement's full text spans multiple output
lines, but only its *first* line (the `READ` header) is missing after pass
1 — its child line is already in place from a different row. The code
finds where the already-written child text occurs inside the full
`StmtText`, takes everything before that as the header, and writes it at
`start_idx`. It also writes `END-READ` at `end_idx`.

### 4. Paragraph placement and PROCEDURE DIVISION (pass 3)
`get_paragraph_positions()` looks at rows where `kind == "cobol_paragraph"`,
orders them by the `paraList.N` index embedded in `node_path`, and computes
a target line for each of up to three paragraphs:
- Paragraph 0 goes two lines above the first statement line.
- Paragraph 1 goes two lines above the first `READNEXT` (if one exists).
- Paragraph 2 goes two lines above the first statement after the
  `READNEXT` block (if one exists).

Each target is a *preferred* line — if it's already occupied, the write
loop in `reconstruct()` walks forward to the next empty line before
placing the paragraph name, and it never overwrites an existing
reconstructed line. This logic is intentionally still shaped around the
3-paragraph VSAMPRGM layout (see **Known limitation** below).

`PROCEDURE DIVISION.` is no longer a hardcoded offset. After all paragraphs
are placed, the code looks at wherever paragraph 0 actually landed and
targets one line above it. If that line is empty, `PROCEDURE DIVISION.`
goes there. If it's occupied, every already-placed paragraph is pushed
down one line (to its own next empty slot) to free up paragraph 0's
original line, and `PROCEDURE DIVISION.` is written there instead — so it
never silently fails to appear just because the line above paragraph 0 was
already used.

### 5. File-description overlay (pass 4, optional)
If `--file-description` is supplied, `normalize_file_description()` applies
the same alias-matching and line-number remap as the main table, using a
separate alias map (`FILE_DESCRIPTION_ALIASES`) that additionally covers
FILE-CONTROL-specific fields: `DDName`, `organization`, `access`,
`Keyinformation`, `FileStatusVariable`.

- `build_file_data_clause()` turns one variable row into a COBOL data
  clause: `<level> <name>` plus any of `REDEFINES`, `RENAMES`, `PIC`,
  usage, `SIGN IS`, `OCCURS ... TIMES` (with `DEPENDING ON` / `INDEXED BY`),
  and `VALUE`, terminated with a period. Zero/negative `OCCURS` bounds and
  blank/`[]` `DEPENDING ON`/`INDEXED BY` values are treated as absent.
- `build_select_entries()` builds one `SELECT` block per record file
  (matched to its `ASSIGN TO` DD name, if any, by a shared `FDLIST` index),
  optionally followed by `ORGANIZATION IS` (normalizing `RECORD INDEXED` →
  `INDEXED` and `RECORD SEQUENTIAL` → `SEQUENTIAL`), `ACCESS MODE IS`,
  `RECORD KEY IS`, and `FILE STATUS IS`.
- `overlay_file_description()` writes each data clause into `ArrayCOB` at
  its own `start_idx`, and for every level-01 item, writes `FD <file>.`
  immediately above it (if that line is free — otherwise it warns instead
  of overwriting). Once the first `FD` line's position is known, it treats
  everything above it as reserved space and writes the full
  `IDENTIFICATION DIVISION.` / `PROGRAM-ID.` / `ENVIRONMENT DIVISION.` /
  `INPUT-OUTPUT SECTION.` / `FILE-CONTROL.` / `<SELECT entries>` /
  `DATA DIVISION.` / `FILE SECTION.` preamble into those lines — warning
  (without overwriting) if there isn't enough room or a slot is already
  occupied.

### 6. Period rules (pass 5)
`add_periods()` first identifies which lines belong to multiline
statement blocks (`start_idx != end_idx` in the source data) — interior
lines of a block never get a period, only the last line does. Then, for
every other non-empty line: a paragraph label (already ends in `.`) is
left alone, a line that already ends in `.` is left alone, a line starting
with `PERFORM ` never gets a period, and everything else gets one appended.

### 7. Output
`write_cobol()` converts any remaining `None` entries to blank lines,
strips trailing blank lines (unless `--keep-trailing-blank` is set), and
writes the result as UTF-8 with LF line endings. `main()` reports how many
of the output lines are non-empty relative to the total, and in `-v`
mode also prints per-row line-mapping diagnostics (for `OPEN`, `READNEXT`,
`IF`, `WRITE`, `STOP_RUN`) plus every warning collected along the way
(e.g. a missing `OPEN` field, an `FD` that couldn't be placed, not enough
reserved space for the FILE-CONTROL preamble).

## Known limitation

Paragraph placement (step 4 above) assumes at most three paragraphs in a
specific shape — first statement group, then a `READNEXT`-anchored
paragraph, then a paragraph after the `READNEXT` block — because that's
the shape of the VSAMPRGM sample this script was built against. A COBOL
program with a different paragraph count or structure will not get all of
its paragraph headers placed correctly. `PROCEDURE DIVISION.` placement
was generalized (see step 4) to no longer depend on this assumption, but
per-paragraph placement itself was intentionally left unchanged.

## Files in this directory

| File | Purpose |
| --- | --- |
| `updated_2_kdm_2_cobol.py` | The reconstruction script |
| `Final_graphjson_neo4j.xlsx` | Sample KDM graph export (main input) |
| `filedescription.xlsx`, `filedescription_2.xlsx` | Sample file-description exports (`--file-description` input) |
| `VSAMPRGM.COB` | Original hand-written COBOL source the KDM export was derived from |
| `VSAMPRGM_RECONSTRUCTED.cob` | Script output for comparison against `VSAMPRGM.COB` |
| `VSAMPRGM.exe`, `VSAMPRGM_0.exe`, `exe_Folder/` | Compiled program binaries |
| `KDM_2_COBOL_Pseudocode_Updated.docx` | Narrative pseudocode matching this README |
| `GraphJson.json`, `cmd_neo4j.txt`, `neo4j_cmd.txt` | Raw KDM graph JSON and the Neo4j/Cypher commands used to load/query it |
| `vsamoff.dat`, `oemp.dat` | Sample VSAM data files |
